export const PRD_CONTENT = {
  title: 'HydroPulse: Intelligent Small Hydropower Plant (SHP) Management & Resilience Platform',
  sihTrack: 'Smart India Hackathon (SIH) - Clean Energy & Smart Water Infrastructure',
  executiveSummary: 'HydroPulse is a specialized industrial intelligence platform designed for run-of-river and small hydropower installations (1 to 25 MW). It bridges the critical operational gap between physics-informed hydraulic machinery dynamics, severe Himalayan abrasive quartz sediment degradation, and automated grid dispatch optimization.',
  objectives: [
    'Mitigate severe hydro-abrasive runner erosion conforming to IEC 62364 standard, reducing unscheduled turbine downtime by 35%.',
    '72-hour ahead multi-source sediment and turbidity forecasting utilizing catchment hydrological models (XGBoost Regressor).',
    'Real-time Hill chart operating point tracking and multi-unit dispatch optimization for 3.2% - 5.5% net generation uplift.',
    'Early resilience warnings for extreme Himalayan events (GLOFs, cloudbursts, tailwater surges) protecting plant structural assets.',
    'Enable remote, low-bandwidth telemetry synchronization across decentralized mountain powerhouses with offline local caching.',
  ],
  functionalRequirements: [
    { module: 'Telemetry & SCADA', req: 'Sub-second sensor acquisition (flow, head, RPM, 3-axis vibration, RTD bearing temps) via Modbus RTU / OPC-UA gateway.' },
    { module: 'Sediment Intelligence', req: 'Physics-informed quartz abrasion calculation with 72h XGBoost turbidity predictions and automated desilter purge triggers.' },
    { module: 'Turbine Intelligence', req: 'Fast Fourier Transform (FFT) vibration harmonic decomposition (1X, 2X, blade pass frequency) and acoustic cavitation detection.' },
    { module: 'Operating Optimizer', req: 'Non-linear constraint optimization solver for optimal guide vane opening (GVO) and head loss minimization.' },
    { module: 'Resilience Engine', req: 'Automated SOP execution and emergency radial spillway gate control logic during catchment surge events.' },
    { module: 'What-If Simulation', req: 'Real-time client-side hydraulic simulation solving Navier-Stokes / Euler turbine equations with dynamic friction loss.' },
  ],
};

export const USER_ROLES_DATA = [
  {
    role: 'Plant Shift Operator',
    badge: 'Operations',
    description: 'On-site control room operator managing real-time turbine start/stop, guide vane opening trims, desilter flushing, and immediate alarm acknowledgements.',
    permissions: [
      'View real-time SCADA cross-section telemetry and sensor tables',
      'Execute manual guide vane opening (GVO) adjustments within safety interlocks',
      'Trigger desilting chamber hopper flush cycles',
      'Acknowledge and annotate operational alerts',
    ],
  },
  {
    role: 'Chief Hydrologist / Silt Analyst',
    badge: 'Hydrology',
    description: 'Catchment specialist overseeing hydrological radar forecasts, sediment particle size distribution (PSD), quartz petrographic audits, and 72h catchment inflow.',
    permissions: [
      'Configure rainfall-runoff hydrological catchment coefficients',
      'Upload laboratory quartz petrographic and hardness test reports',
      'Adjust sediment warning and trip thresholds (NTU / ppm)',
      'Review watershed GIS contour layers and upstream gauging telemetry',
    ],
  },
  {
    role: 'Grid Dispatcher (SLDC / NRLDC)',
    badge: 'Grid Dispatch',
    description: 'State Load Despatch Centre coordinator managing grid frequency support, Time-of-Day (ToD) tariff peaking schedules, and availability declarations.',
    permissions: [
      'Issue active power dispatch setpoints (MW) under grid code regulations',
      'Schedule peaker reservoir drawdown windows',
      'Monitor Plant Availability Factor (PAF) and declared capacity',
      'Audit commercial deviations under Availability Based Tariff (ABT)',
    ],
  },
  {
    role: 'Plant Maintenance & Reliability Lead',
    badge: 'Engineering',
    description: 'Mechanical and electrical reliability engineer responsible for vibration FFT analysis, bearing lubrication thermography, and runner overhaul planning.',
    permissions: [
      'Configure ISO 10816-5 vibration limits and FFT harmonic band alarms',
      'Log runner blade dye-penetrant and ultrasonic inspection results',
      'Manage Renovation, Modernization & Uprating (RM&U) feasibility studies',
      'Approve runner HVOF coating and overhaul work orders',
    ],
  },
  {
    role: 'SIH Evaluator / Regulatory Auditor',
    badge: 'Auditor',
    description: 'Government, CEA, or Hackathon jury member assessing compliance with Central Electricity Authority (CEA) norms, environmental flow compliance, and safety standards.',
    permissions: [
      'Full read-only audit access across all 12 platform modules',
      'Export compliance certificates and historical generation logs',
      'Inspect mathematical physics formulas and ML model validation metrics',
    ],
  },
];

export const SUPABASE_SCHEMA_SQL = `-- ============================================================================
-- HydroPulse PostgreSQL Schema for Supabase
-- Small Hydropower Plant (SHP) Intelligence & Resilience Platform
-- ============================================================================

-- Enable PostGIS for catchment and river spatial indexing
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";

-- 1. Hydropower Plants
CREATE TABLE IF NOT EXISTS public.hydro_plants (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code VARCHAR(32) UNIQUE NOT NULL,
  name VARCHAR(128) NOT NULL,
  state VARCHAR(64) NOT NULL,
  river_basin VARCHAR(128) NOT NULL,
  capacity_mw NUMERIC(6, 2) NOT NULL,
  net_head_m NUMERIC(6, 2) NOT NULL,
  design_discharge_m3s NUMERIC(6, 2) NOT NULL,
  turbine_type VARCHAR(32) NOT NULL CHECK (turbine_type IN ('Francis', 'Pelton', 'Kaplan', 'Crossflow')),
  units_count INT NOT NULL DEFAULT 2,
  quartz_content_pct NUMERIC(5, 2) DEFAULT 65.0,
  latitude NUMERIC(10, 6) NOT NULL,
  longitude NUMERIC(10, 6) NOT NULL,
  elevation_m NUMERIC(6, 1) NOT NULL,
  catchment_area_km2 NUMERIC(8, 2),
  status VARCHAR(32) DEFAULT 'nominal' CHECK (status IN ('nominal', 'advisory', 'critical')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Real-Time Telemetry Stream (High-frequency time-series table)
CREATE TABLE IF NOT EXISTS public.plant_telemetry (
  id BIGSERIAL PRIMARY KEY,
  plant_id UUID REFERENCES public.hydro_plants(id) ON DELETE CASCADE,
  unit_id VARCHAR(32) NOT NULL,
  recorded_at TIMESTAMPTZ NOT NULL,
  river_flow_m3s NUMERIC(6, 2) NOT NULL,
  net_head_m NUMERIC(6, 2) NOT NULL,
  tailwater_m NUMERIC(6, 2) NOT NULL,
  power_mw NUMERIC(6, 3) NOT NULL,
  expected_power_mw NUMERIC(6, 3) NOT NULL,
  efficiency_pct NUMERIC(5, 2) NOT NULL,
  rpm NUMERIC(6, 1) NOT NULL,
  vibration_rms_mms NUMERIC(5, 2) NOT NULL,
  bearing_temp_c NUMERIC(5, 2) NOT NULL,
  turbidity_ntu NUMERIC(7, 1) NOT NULL,
  guide_vane_pct NUMERIC(5, 2) NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_telemetry_plant_time ON public.plant_telemetry (plant_id, recorded_at DESC);

-- 3. Model 1: Sediment & Turbidity 72h Forecasts
CREATE TABLE IF NOT EXISTS public.sediment_forecasts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  plant_id UUID REFERENCES public.hydro_plants(id) ON DELETE CASCADE,
  forecast_generated_at TIMESTAMPTZ NOT NULL,
  target_timestamp TIMESTAMPTZ NOT NULL,
  rainfall_mm NUMERIC(5, 1) NOT NULL,
  cumulative_rainfall_mm NUMERIC(6, 1) NOT NULL,
  predicted_flow_m3s NUMERIC(6, 2) NOT NULL,
  predicted_turbidity_ntu NUMERIC(7, 1) NOT NULL,
  quartz_fraction NUMERIC(4, 2) NOT NULL,
  erosion_risk_level VARCHAR(32) NOT NULL,
  estimated_loss_mwh NUMERIC(6, 2) NOT NULL,
  recommended_action TEXT NOT NULL
);

-- 4. Model 3: Turbine Runner Health & Degradation Logs
CREATE TABLE IF NOT EXISTS public.turbine_health_records (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  plant_id UUID REFERENCES public.hydro_plants(id) ON DELETE CASCADE,
  unit_id VARCHAR(32) NOT NULL,
  health_score INT NOT NULL CHECK (health_score BETWEEN 0 AND 100),
  erosion_stage VARCHAR(64) NOT NULL,
  hours_run INT NOT NULL,
  cavitation_db NUMERIC(5, 1),
  runner_material VARCHAR(128) NOT NULL,
  coating_type VARCHAR(128),
  last_overhaul_date DATE,
  logged_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Operational Alerts & Incident Triage
CREATE TABLE IF NOT EXISTS public.operational_alerts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  plant_id UUID REFERENCES public.hydro_plants(id) ON DELETE CASCADE,
  unit_id VARCHAR(32),
  alert_level VARCHAR(32) NOT NULL CHECK (alert_level IN ('info', 'warning', 'critical')),
  source_module VARCHAR(64) NOT NULL,
  title VARCHAR(256) NOT NULL,
  details TEXT NOT NULL,
  mitigation_sop TEXT NOT NULL,
  is_acknowledged BOOLEAN DEFAULT FALSE,
  acknowledged_by UUID,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Row Level Security (RLS) Policies
ALTER TABLE public.hydro_plants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.plant_telemetry ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.operational_alerts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public Read Access for Authorized Operators"
  ON public.hydro_plants FOR SELECT USING (true);

CREATE POLICY "Telemetry Insert from Edge SCADA Gateway"
  ON public.plant_telemetry FOR INSERT WITH CHECK (auth.role() = 'service_role');
`;

export const API_ENDPOINTS_SPEC = [
  {
    category: 'Telemetry & SCADA',
    method: 'GET',
    path: '/api/v1/plants/:plantId/telemetry/live',
    description: 'Retrieves current sub-minute sensor readings (flow, head, RPM, vibration FFT, RTD temps, active MW).',
    responseSample: `{
  "plant_id": "chamera_aux",
  "timestamp": "2026-09-26T20:00:00Z",
  "flow_m3s": 11.2,
  "head_m": 116.8,
  "active_mw": 10.42,
  "expected_mw": 11.15,
  "efficiency_pct": 90.1,
  "units": [
    { "id": "unit-1", "mw": 5.48, "gvo_pct": 88, "vibe_mms": 1.95, "temp_c": 52.4 },
    { "id": "unit-2", "mw": 4.94, "gvo_pct": 91, "vibe_mms": 3.35, "temp_c": 61.2 }
  ]
}`,
  },
  {
    category: 'Sediment Intelligence (Model 1)',
    method: 'GET',
    path: '/api/v1/plants/:plantId/sediment/forecast?horizon=72h',
    description: 'Returns 72-hour ahead XGBoost sedimentation forecast, quartz abrasion rate, and desilter trigger states.',
    responseSample: `{
  "plant_id": "chamera_aux",
  "model_version": "XGBoost-Reg-v2.4",
  "confidence_r2": 0.942,
  "forecast": [
    { "hour": "+6h", "predicted_ntu": 820, "risk": "elevated", "loss_mwh": 1.15, "action": "Trim Unit 2 GVO" },
    { "hour": "+18h", "predicted_ntu": 1850, "risk": "critical", "loss_mwh": 3.85, "action": "Derate Unit 2 or trip" }
  ]
}`,
  },
  {
    category: 'Dynamic Optimization (Model 2)',
    method: 'POST',
    path: '/api/v1/plants/:plantId/optimizer/solve',
    description: 'Solves non-linear unit commitment and guide vane aperture allocation to maximize revenue under prevailing tariff.',
    responseSample: `{
  "status": "converged",
  "current_total_mw": 10.42,
  "optimal_total_mw": 10.78,
  "generation_uplift_mw": 0.36,
  "revenue_gain_inr_day": 36720,
  "recommended_dispatch": [
    { "unit_id": "unit-1", "optimal_gvo": 84, "target_mw": 5.82 },
    { "unit_id": "unit-2", "optimal_gvo": 74, "target_mw": 4.96 }
  ]
}`,
  },
  {
    category: 'Turbine Diagnostics (Model 3)',
    method: 'GET',
    path: '/api/v1/plants/:plantId/turbines/:unitId/health',
    description: 'Returns physics-informed turbine health score, FFT vibration spectrum, and IEC 62364 erosion stage.',
    responseSample: `{
  "unit_id": "unit-1",
  "health_score": 89,
  "degradation_class": "Class A (Normal)",
  "erosion_stage": "Stage 1 (Polishing)",
  "blade_life_remaining_months": 34.2,
  "cavitation_risk": "Safe",
  "vibration_zone": "Zone A (ISO 10816-5)"
}`,
  },
  {
    category: 'Resilience Engine',
    method: 'POST',
    path: '/api/v1/plants/:plantId/resilience/simulate-stress',
    description: 'Simulates catchment stress scenarios (GLOF, cloudburst, debris) and yields automated SOP checklist.',
    responseSample: `{
  "scenario": "GLOF_Flash_Flood",
  "peak_surge_discharge_m3s": 52.0,
  "time_to_peak_hours": 2.4,
  "action_protocol": "Spillway_Radial_Gates_Open_Full",
  "unit_protection_state": "Trip_To_House_Load"
}`,
  },
  {
    category: 'Real-Time Telemetry (WebSocket)',
    method: 'WSS',
    path: 'wss://api.hydropulse.gov.in/v1/stream/:plantId',
    description: 'Bi-directional WebSocket for sub-second SCADA push updates and emergency trip acknowledgements.',
    responseSample: `{
  "event": "TELEMETRY_FRAME",
  "tick": 1727380800000,
  "turbidity_ntu": 482.4,
  "vibe_unit1_rms": 1.96,
  "vibe_unit2_rms": 3.38,
  "grid_frequency_hz": 50.02
}`,
  },
];

export const IOT_HARDWARE_BOM = [
  { item: 'Acoustic / Laser Turbidity Meter', model: 'Endress+Hauser Turbimax CUS51D', range: '0 - 4000 NTU', location: 'Desilting Basin Inlet & Outlet' },
  { item: 'Ultrasonic Transit-Time Flowmeter', model: 'KROHNE OPTISONIC 6300 (Clamp-on)', accuracy: '±0.5% of reading', location: 'High-Pressure Steel Penstock' },
  { item: 'Piezoresistive Water Level / Head Probe', model: 'Keller Series 36XW High Precision', accuracy: '0.05% FS', location: 'Forebay Tank & Tailrace Channel' },
  { item: 'Triaxial Industrial Accelerometer', model: 'PCB Piezotronics 607A11 (ISO 10816)', frequency: '0.5 Hz - 10 kHz', location: 'Turbine Guide Bearing & Headcover' },
  { item: 'Duplex Pt100 RTD Temperature Sensors', model: 'Tempsens Industrial Duplex RTD', range: '-50 to 200°C', location: 'Thrust Pads, Guide Bearings, Stator' },
  { item: 'Edge SCADA Gateway / Industrial IPC', model: 'Advantech UNO-2484G (Modbus/OPC-UA)', os: 'Debian Linux + Edge Runtime', location: 'Powerhouse Control Room Cabinet' },
];
