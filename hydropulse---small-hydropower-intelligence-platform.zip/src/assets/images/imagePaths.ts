// Saved image paths from generate_image tool
export const IMAGES = {
  powerhouseFacility: '/src/assets/images/shp_powerhouse_facility_1790478114616.jpg',
  turbineRunnerInspection: '/src/assets/images/hydro_turbine_runner_inspection_1790478125825.jpg',
  himalayanCatchment: '/src/assets/images/himalayan_river_catchment_1790478140127.jpg',
};
