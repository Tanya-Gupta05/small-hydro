/**
 * HydroPulse - Small Hydropower Plant (SHP) Intelligence Platform
 * Smart India Hackathon (SIH) Prototype
 */

import React, { useState } from 'react';
import { Plant, AlertItem } from './types/hydro';
import { HYDRO_PLANTS, ACTIVE_ALERTS } from './data/mockHydroData';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';

// 12 Distinct Navigable Modules
import { CommandCenter } from './components/pages/CommandCenter';
import { SedimentIntelligence } from './components/pages/SedimentIntelligence';
import { TurbineIntelligence } from './components/pages/TurbineIntelligence';
import { OperatingOptimization } from './components/pages/OperatingOptimization';
import { ResilienceEngine } from './components/pages/ResilienceEngine';
import { GisMapping } from './components/pages/GisMapping';
import { WhatIfSimulator } from './components/pages/WhatIfSimulator';
import { PlantRevamp } from './components/pages/PlantRevamp';
import { PerformanceAnalytics } from './components/pages/PerformanceAnalytics';
import { RemoteMonitoring } from './components/pages/RemoteMonitoring';
import { MlArchitecture } from './components/pages/MlArchitecture';
import { TechnicalSpecs } from './components/pages/TechnicalSpecs';

import { Menu, X } from 'lucide-react';

export default function App() {
  const [currentPlant, setCurrentPlant] = useState<Plant>(HYDRO_PLANTS[0]);
  const [activeTab, setActiveTab] = useState<string>('command_center');
  const [alerts, setAlerts] = useState<AlertItem[]>(ACTIVE_ALERTS);
  const [isLiveStreaming, setIsLiveStreaming] = useState<boolean>(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);

  const handleAcknowledgeAlert = (id: string) => {
    setAlerts((prev) =>
      prev.map((a) => (a.id === id ? { ...a, acknowledged: !a.acknowledged } : a))
    );
  };

  const handleToggleStreaming = () => {
    setIsLiveStreaming((prev) => !prev);
  };

  const unreadAlertsCount = alerts.filter((a) => !a.acknowledged).length;

  return (
    <div className="min-h-screen bg-[#080d19] text-slate-100 flex flex-col font-sans">
      {/* Top Bar Header */}
      <Header
        currentPlant={currentPlant}
        onSelectPlant={(plant) => setCurrentPlant(plant)}
        activeTab={activeTab}
        onTabChange={(tab) => setActiveTab(tab)}
        isLiveStreaming={isLiveStreaming}
        onToggleStreaming={handleToggleStreaming}
        unreadAlertsCount={unreadAlertsCount}
      />

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar with 12 distinct pages */}
        <Sidebar
          activeTab={activeTab}
          onTabChange={(tab) => setActiveTab(tab)}
          isOpenMobile={isMobileMenuOpen}
          onCloseMobile={() => setIsMobileMenuOpen(false)}
        />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-[#080d19]">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Mobile menu trigger */}
            <div className="lg:hidden flex items-center justify-between pb-3 border-b border-slate-800">
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="px-2.5 py-1.5 rounded bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300 flex items-center gap-1.5"
              >
                {isMobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
                <span>Navigation Modules</span>
              </button>
              <div className="text-xs font-mono text-slate-400">
                {currentPlant.name.split(' ')[0]}
              </div>
            </div>

            {/* Dynamic Page Router */}
            {activeTab === 'command_center' && (
              <CommandCenter
                currentPlant={currentPlant}
                alerts={alerts}
                onAcknowledgeAlert={handleAcknowledgeAlert}
                onNavigate={(tab) => setActiveTab(tab)}
              />
            )}

            {activeTab === 'monitoring' && (
              <RemoteMonitoring
                currentPlant={currentPlant}
                isStreaming={isLiveStreaming}
                onToggleStreaming={handleToggleStreaming}
              />
            )}

            {activeTab === 'sediment' && (
              <SedimentIntelligence currentPlant={currentPlant} />
            )}

            {activeTab === 'turbine_ai' && (
              <TurbineIntelligence currentPlant={currentPlant} />
            )}

            {activeTab === 'operating_opt' && (
              <OperatingOptimization currentPlant={currentPlant} />
            )}

            {activeTab === 'resilience' && (
              <ResilienceEngine currentPlant={currentPlant} />
            )}

            {activeTab === 'gis_map' && (
              <GisMapping currentPlant={currentPlant} />
            )}

            {activeTab === 'what_if' && (
              <WhatIfSimulator currentPlant={currentPlant} />
            )}

            {activeTab === 'performance' && (
              <PerformanceAnalytics currentPlant={currentPlant} />
            )}

            {activeTab === 'revamp' && (
              <PlantRevamp currentPlant={currentPlant} />
            )}

            {activeTab === 'ml_pipeline' && (
              <MlArchitecture currentPlant={currentPlant} />
            )}

            {activeTab === 'tech_specs' && (
              <TechnicalSpecs />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
