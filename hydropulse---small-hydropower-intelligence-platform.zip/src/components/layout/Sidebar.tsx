import React from 'react';
import {
  LayoutDashboard,
  Waves,
  Gauge,
  Sliders,
  ShieldAlert,
  MapPin,
  Cpu,
  Wrench,
  BarChart3,
  Radio,
  Network,
  FileCode2,
  ChevronRight,
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onTabChange,
  isOpenMobile,
  onCloseMobile,
}) => {
  const navSections = [
    {
      group: 'OPERATIONAL COCKPIT',
      items: [
        {
          id: 'command_center',
          label: 'Command Center',
          subtitle: 'Real-time overview & alerts',
          icon: LayoutDashboard,
          accent: 'blue',
        },
        {
          id: 'monitoring',
          label: 'Remote Monitoring',
          subtitle: 'SCADA schematic & sensors',
          icon: Radio,
          accent: 'blue',
        },
      ],
    },
    {
      group: 'CORE INTELLIGENCE',
      items: [
        {
          id: 'sediment',
          label: 'Sediment & Erosion',
          subtitle: '72h forecasting & MWh losses',
          icon: Waves,
          accent: 'amber',
        },
        {
          id: 'turbine_ai',
          label: 'Turbine Intelligence',
          subtitle: 'Hill chart & FFT vibration',
          icon: Gauge,
          accent: 'purple',
        },
        {
          id: 'operating_opt',
          label: 'Operating Optimization',
          subtitle: 'Dynamic GVO & dispatch',
          icon: Sliders,
          accent: 'green',
        },
        {
          id: 'resilience',
          label: 'Resilience Engine',
          subtitle: 'GLOF, flood & drought SOPs',
          icon: ShieldAlert,
          accent: 'red',
        },
      ],
    },
    {
      group: 'SITE & DECISION INTELLIGENCE',
      items: [
        {
          id: 'gis_map',
          label: 'GIS Catchment Intel',
          subtitle: 'River basin & terrain layers',
          icon: MapPin,
          accent: 'blue',
        },
        {
          id: 'what_if',
          label: 'What-If Simulator',
          subtitle: 'Hydraulic physics sandbox',
          icon: Cpu,
          accent: 'purple',
        },
        {
          id: 'performance',
          label: 'Performance Analytics',
          subtitle: 'PLF, PAF & water utilization',
          icon: BarChart3,
          accent: 'green',
        },
        {
          id: 'revamp',
          label: 'Plant Revamp (RM&U)',
          subtitle: 'Runner coatings & modernization',
          icon: Wrench,
          accent: 'amber',
        },
      ],
    },
    {
      group: 'SYSTEM ARCHITECTURE',
      items: [
        {
          id: 'ml_pipeline',
          label: 'ML Architecture',
          subtitle: '3-Model cascade pipeline',
          icon: Network,
          accent: 'purple',
        },
        {
          id: 'tech_specs',
          label: 'Technical Specs & PRD',
          subtitle: 'Supabase DDL & API contracts',
          icon: FileCode2,
          accent: 'slate',
        },
      ],
    },
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpenMobile && (
        <div
          className="fixed inset-0 bg-black/70 backdrop-blur-xs z-40 lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={`fixed lg:static top-14 bottom-0 left-0 w-64 bg-[#090e1a] border-r border-slate-800/80 z-40 flex flex-col justify-between overflow-y-auto transition-transform duration-200 lg:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="py-3 px-2 space-y-5">
          {navSections.map((section, idx) => (
            <div key={idx} className="space-y-1">
              <div className="px-3 text-[10px] font-mono font-semibold tracking-wider text-slate-500 uppercase">
                {section.group}
              </div>
              <div className="space-y-0.5">
                {section.items.map((item) => {
                  const isActive = activeTab === item.id;
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onTabChange(item.id);
                        onCloseMobile();
                      }}
                      className={`w-full text-left px-3 py-2 rounded text-xs transition-all flex items-center justify-between group ${
                        isActive
                          ? 'bg-slate-800/90 text-white font-medium shadow-xs border-l-2 border-sky-400'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850/50'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Icon
                          className={`w-4 h-4 shrink-0 transition-colors ${
                            isActive
                              ? item.accent === 'blue'
                                ? 'text-sky-400'
                                : item.accent === 'green'
                                ? 'text-emerald-400'
                                : item.accent === 'amber'
                                ? 'text-amber-400'
                                : item.accent === 'red'
                                ? 'text-rose-400'
                                : 'text-purple-400'
                              : 'text-slate-500 group-hover:text-slate-300'
                          }`}
                        />
                        <div className="truncate">
                          <div className="truncate leading-snug">{item.label}</div>
                          <div className="text-[10px] text-slate-500 truncate group-hover:text-slate-400">
                            {item.subtitle}
                          </div>
                        </div>
                      </div>
                      {isActive && (
                        <ChevronRight className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Quiet footer compliance mark */}
        <div className="p-3 border-t border-slate-800/80 bg-[#070b14] text-[11px] text-slate-500">
          <div className="flex items-center justify-between font-mono">
            <span>SIH 2026 PROTOTYPE</span>
            <span className="text-emerald-400 font-semibold">ONLINE</span>
          </div>
          <div className="text-[10px] text-slate-600 mt-0.5">
            IEC 60193 / IEC 62364 Hydro Standard
          </div>
        </div>
      </aside>
    </>
  );
};
