import React from 'react';
import { Plant } from '../../types/hydro';
import { HYDRO_PLANTS } from '../../data/mockHydroData';
import { Activity, Bell, RefreshCw, ShieldAlert, Cpu } from 'lucide-react';

interface HeaderProps {
  currentPlant: Plant;
  onSelectPlant: (plant: Plant) => void;
  activeTab: string;
  onTabChange: (tab: string) => void;
  isLiveStreaming: boolean;
  onToggleStreaming: () => void;
  unreadAlertsCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentPlant,
  onSelectPlant,
  activeTab,
  onTabChange,
  isLiveStreaming,
  onToggleStreaming,
  unreadAlertsCount,
}) => {
  return (
    <header className="h-14 border-b border-slate-800/80 bg-[#0a101f] px-4 flex items-center justify-between z-30 shrink-0">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-3">
        <a
          href="#command_center"
          onClick={(e) => {
            e.preventDefault();
            onTabChange('command_center');
          }}
          className="text-base font-bold tracking-tight text-white flex items-center gap-2 hover:text-sky-400 transition-colors"
        >
          <div className="w-2.5 h-2.5 rounded-sm bg-sky-500 shadow-[0_0_10px_rgba(14,165,233,0.8)]" />
          <span>HydroPulse</span>
        </a>
        <span className="text-slate-600 hidden sm:inline" aria-hidden="true">/</span>
        <span className="text-xs font-mono text-slate-400 hidden sm:inline truncate max-w-xs">
          {currentPlant.name}
        </span>
      </div>

      {/* Zone 2: Clean breadcrumbs or rapid jump links */}
      <div className="hidden lg:flex items-center gap-5 text-xs text-slate-400 font-medium">
        <span className="text-slate-500">Basin: <strong className="text-slate-300 font-semibold">{currentPlant.river}</strong></span>
        <span aria-hidden="true" className="text-slate-700">·</span>
        <span className="text-slate-500">Rated: <strong className="text-slate-300 font-mono">{currentPlant.capacityMW} MW</strong></span>
        <span aria-hidden="true" className="text-slate-700">·</span>
        <span className="text-slate-500">Turbine: <strong className="text-slate-300">{currentPlant.turbineType} ({currentPlant.unitsCount} Units)</strong></span>
        <span aria-hidden="true" className="text-slate-700">·</span>
        <span className="text-slate-500">Quartz: <strong className="text-amber-400 font-mono">{currentPlant.quartzContentPercent}%</strong></span>
      </div>

      {/* Zone 3: 1-2 primary actions & Plant Selector */}
      <div className="flex items-center gap-2.5">
        {/* Plant Selector Dropdown */}
        <div className="relative">
          <select
            value={currentPlant.id}
            onChange={(e) => {
              const selected = HYDRO_PLANTS.find((p) => p.id === e.target.value);
              if (selected) onSelectPlant(selected);
            }}
            className="h-8 bg-slate-900 border border-slate-700/80 rounded px-2.5 text-xs font-medium text-slate-200 hover:border-slate-600 focus:outline-none focus:border-sky-500 transition-colors cursor-pointer"
          >
            {HYDRO_PLANTS.map((plant) => (
              <option key={plant.id} value={plant.id}>
                {plant.name}
              </option>
            ))}
          </select>
        </div>

        {/* Live SCADA Stream Toggle */}
        <button
          onClick={onToggleStreaming}
          title={isLiveStreaming ? 'SCADA Telemetry: Streaming Active' : 'SCADA Telemetry: Paused'}
          className={`h-8 px-2.5 rounded text-xs font-mono font-medium flex items-center gap-1.5 transition-colors border ${
            isLiveStreaming
              ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800/60 hover:bg-emerald-900/40'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
          }`}
        >
          <span
            className={`w-1.5 h-1.5 rounded-full ${
              isLiveStreaming ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'
            }`}
          />
          <span className="hidden sm:inline">{isLiveStreaming ? 'LIVE SCADA' : 'PAUSED'}</span>
        </button>

        {/* Alert Triage Quick Trigger */}
        <button
          onClick={() => onTabChange('command_center')}
          className="h-8 px-2 rounded text-xs font-mono text-slate-300 bg-slate-900 border border-slate-800 hover:border-slate-700 hover:text-white transition-colors relative flex items-center gap-1.5"
          title="Operational Alerts"
        >
          <Bell className="w-3.5 h-3.5 text-slate-400" />
          {unreadAlertsCount > 0 && (
            <span className="text-[10px] font-bold text-amber-300">
              {unreadAlertsCount}
            </span>
          )}
        </button>

        {/* SIH 2026 Audit Mode / Specs Link */}
        <button
          onClick={() => onTabChange('tech_specs')}
          className={`h-8 px-2.5 rounded text-xs font-medium transition-colors border hidden sm:flex items-center gap-1.5 ${
            activeTab === 'tech_specs'
              ? 'bg-purple-950/60 text-purple-200 border-purple-700/80'
              : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-purple-800 hover:text-purple-300'
          }`}
        >
          <Cpu className="w-3.5 h-3.5 text-purple-400" />
          <span>SIH Specs</span>
        </button>
      </div>
    </header>
  );
};
