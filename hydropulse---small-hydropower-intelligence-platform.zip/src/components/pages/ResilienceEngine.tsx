import React, { useState } from 'react';
import { Plant, ResilienceScenario } from '../../types/hydro';
import { RESILIENCE_SCENARIOS } from '../../data/mockHydroData';
import { MetricCard } from '../common/MetricCard';
import {
  ShieldAlert,
  AlertTriangle,
  Waves,
  CloudRain,
  Flame,
  CheckCircle2,
  Play,
  RotateCcw,
  Clock,
  ArrowRight,
} from 'lucide-react';

interface ResilienceEngineProps {
  currentPlant: Plant;
}

export const ResilienceEngine: React.FC<ResilienceEngineProps> = ({ currentPlant }) => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>('sc-2');
  const [isExecutingDrill, setIsExecutingDrill] = useState<boolean>(false);
  const [drillCompleted, setDrillCompleted] = useState<boolean>(false);
  const [checkedSteps, setCheckedSteps] = useState<Record<string, boolean>>({});

  const scenarios = RESILIENCE_SCENARIOS;
  const currentScenario = scenarios.find((s) => s.id === selectedScenarioId) || scenarios[0];

  const handleToggleStep = (stepIdx: number) => {
    const key = `${selectedScenarioId}-${stepIdx}`;
    setCheckedSteps((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleRunEmergencyDrill = () => {
    setIsExecutingDrill(true);
    setDrillCompleted(false);
    setTimeout(() => {
      // Automatically check all steps
      const newChecked: Record<string, boolean> = { ...checkedSteps };
      currentScenario.recommendedSOP.forEach((_, idx) => {
        newChecked[`${selectedScenarioId}-${idx}`] = true;
      });
      setCheckedSteps(newChecked);
      setIsExecutingDrill(false);
      setDrillCompleted(true);
      setTimeout(() => setDrillCompleted(false), 5000);
    }, 2200);
  };

  const handleResetChecklist = () => {
    const newChecked = { ...checkedSteps };
    currentScenario.recommendedSOP.forEach((_, idx) => {
      delete newChecked[`${selectedScenarioId}-${idx}`];
    });
    setCheckedSteps(newChecked);
    setDrillCompleted(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="text-xs font-mono text-rose-400 flex items-center gap-1.5 mb-1">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>CORE INTELLIGENCE MODULE 04 · DISASTER RESILIENCE & SOPS</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Hydro Resilience Engine & Extreme Catchment Emergency SOPs
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Stress-testing Himalayan flash floods (GLOF), cloudbursts, intense sediment surges, trash rack debris chokes, and tailwater jumps with automated emergency SCADA response interlocks.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRunEmergencyDrill}
            disabled={isExecutingDrill}
            className={`px-3.5 py-2 rounded text-xs font-semibold flex items-center gap-1.5 transition-colors border ${
              isExecutingDrill
                ? 'bg-rose-950/60 border-rose-800 text-rose-300'
                : drillCompleted
                ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                : 'bg-rose-600 hover:bg-rose-500 text-white shadow-xs'
            }`}
          >
            <Play className={`w-3.5 h-3.5 ${isExecutingDrill ? 'animate-spin' : ''}`} />
            <span>
              {isExecutingDrill
                ? 'Executing SCADA Interlocks...'
                : drillCompleted
                ? 'Drill Executed (100% SOP)'
                : 'Execute Automated SOP'}
            </span>
          </button>
        </div>
      </div>

      {/* Primary Key Resilience Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <MetricCard
          label="Active Stress Scenario"
          value={currentScenario.name.split(' ')[0]}
          unit=""
          subLabel="Trigger"
          subValue={currentScenario.type.toUpperCase()}
          status="critical"
          icon={<ShieldAlert className="w-3.5 h-3.5 text-rose-400" />}
        />
        <MetricCard
          label="Runner Destruction Risk"
          value={currentScenario.runnerDamageRisk}
          unit=""
          subLabel="IEC Failure Mode"
          subValue="Impeller Abrasive Tear"
          status={currentScenario.runnerDamageRisk === 'Catastrophic' ? 'critical' : 'warning'}
          icon={<AlertTriangle className="w-3.5 h-3.5 text-rose-400" />}
        />
        <MetricCard
          label="Generation Loss Impact"
          value={currentScenario.predictedGenerationImpactMWh}
          unit="MWh"
          subLabel="Event Duration"
          subValue="~24 Hours"
          status="warning"
          icon={<Waves className="w-3.5 h-3.5 text-amber-400" />}
        />
        <MetricCard
          label="Spillway Radial Gate Action"
          value="180s"
          unit="Limit"
          subLabel="Full Bypass"
          subValue="Auto-Hydraulic"
          status="nominal"
          icon={<Clock className="w-3.5 h-3.5 text-blue-400" />}
        />
        <MetricCard
          label="SOP Checklist Progress"
          value={`${currentScenario.recommendedSOP.filter((_, i) => checkedSteps[`${selectedScenarioId}-${i}`]).length} / ${currentScenario.recommendedSOP.length}`}
          unit="Done"
          subLabel="Protocol State"
          subValue={drillCompleted ? 'All Verified' : 'In Progress'}
          status={drillCompleted ? 'nominal' : 'advisory'}
          icon={<CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
        />
        <MetricCard
          label="Powerhouse Sump Pumps"
          value="READY"
          unit=""
          subLabel="Dual Redundant"
          subValue="400 m³/h Cap"
          status="nominal"
          icon={<CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
        />
      </div>

      {/* Main Dual Grid: Scenario Selector & Active SOP Protocol Checklist */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: 5 Resilience Scenarios Grid (5 cols) */}
        <div className="lg:col-span-5 bg-[#0c1424] border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <h3 className="text-sm font-semibold text-white">Catchment Hazard Scenarios</h3>
            <span className="text-xs text-slate-500 font-mono">5 Defined Models</span>
          </div>

          <div className="space-y-2.5">
            {scenarios.map((sc) => {
              const isSelected = sc.id === selectedScenarioId;
              return (
                <button
                  key={sc.id}
                  onClick={() => {
                    setSelectedScenarioId(sc.id);
                    setDrillCompleted(false);
                  }}
                  className={`w-full text-left p-3 rounded-lg border transition-all ${
                    isSelected
                      ? 'bg-rose-950/30 border-rose-700/80 shadow-xs'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700 hover:bg-slate-850'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <div className="font-semibold text-xs text-white flex items-center gap-1.5">
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          sc.status === 'active_warning'
                            ? 'bg-rose-500 animate-ping'
                            : sc.status === 'monitoring'
                            ? 'bg-amber-400'
                            : 'bg-slate-500'
                        }`}
                      />
                      <span>{sc.name}</span>
                    </div>
                    <span className="text-[10px] font-mono text-rose-300 font-bold">
                      {sc.predictedGenerationImpactMWh} MWh
                    </span>
                  </div>

                  <div className="text-[11px] text-slate-400 font-mono truncate">
                    Trigger: {sc.triggerCriteria}
                  </div>

                  <div className="mt-2 pt-1.5 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500 font-mono">
                    <span>Damage Risk: <strong className="text-amber-400">{sc.runnerDamageRisk}</strong></span>
                    <span className="uppercase text-sky-400">[{sc.type}]</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Active Protocol Checklist & Gate Interlocks (7 cols) */}
        <div className="lg:col-span-7 bg-[#0c1424] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-rose-400 bg-rose-950/50 px-2 py-0.5 rounded border border-rose-900/60">
                    SOP: {currentScenario.autoDispatchAction}
                  </span>
                </div>
                <h3 className="text-base font-bold text-white mt-1">
                  {currentScenario.name}
                </h3>
              </div>

              <button
                onClick={handleResetChecklist}
                className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1 font-mono transition-colors"
                title="Reset Checklist"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            </div>

            <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 mb-4 text-xs space-y-1">
              <div className="text-slate-400 font-mono text-[11px]">
                <strong className="text-slate-300">SCADA Interlock Trigger:</strong> {currentScenario.triggerCriteria}
              </div>
              <div className="text-slate-400 font-mono text-[11px]">
                <strong className="text-slate-300">Catastrophic Damage Probability:</strong>{' '}
                <span className="text-amber-400 font-bold">{currentScenario.probabilityPercent}%</span> (Catchment risk model)
              </div>
            </div>

            <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wide font-mono mb-2">
              Mandatory Operational Response Checklist
            </h4>

            <div className="space-y-2">
              {currentScenario.recommendedSOP.map((step, idx) => {
                const isChecked = !!checkedSteps[`${selectedScenarioId}-${idx}`];
                return (
                  <div
                    key={idx}
                    onClick={() => handleToggleStep(idx)}
                    className={`p-3 rounded-lg border text-xs flex items-start gap-3 cursor-pointer transition-all ${
                      isChecked
                        ? 'bg-emerald-950/20 border-emerald-800/60 text-emerald-200'
                        : 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-300'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded mt-0.5 flex items-center justify-center shrink-0 border ${
                        isChecked
                          ? 'bg-emerald-500 border-emerald-400 text-slate-950'
                          : 'border-slate-600 bg-slate-800'
                      }`}
                    >
                      {isChecked && <CheckCircle2 className="w-3.5 h-3.5" />}
                    </div>

                    <div className="space-y-0.5">
                      <div className="font-medium leading-relaxed">{step}</div>
                      <div className="text-[10px] font-mono text-slate-500">
                        Step {idx + 1} of {currentScenario.recommendedSOP.length} · Auto-verified via telemetry
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 mt-5 flex items-center justify-between text-xs text-slate-400">
            <span>State Disaster Management Authority (SDMA) synced</span>
            <span className="font-mono text-rose-400 font-bold">READY TO DEPLOY</span>
          </div>
        </div>
      </div>
    </div>
  );
};
