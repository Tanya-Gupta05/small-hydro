import React, { useState } from 'react';
import { Plant } from '../../types/hydro';
import { PERFORMANCE_YEAR_METRICS } from '../../data/mockHydroData';
import { MetricCard } from '../common/MetricCard';
import {
  BarChart3,
  TrendingUp,
  Activity,
  ShieldCheck,
  Zap,
  Clock,
  PieChart,
  ArrowUpRight,
} from 'lucide-react';

interface PerformanceAnalyticsProps {
  currentPlant: Plant;
}

export const PerformanceAnalytics: React.FC<PerformanceAnalyticsProps> = ({ currentPlant }) => {
  const [selectedMonth, setSelectedMonth] = useState<string>('Jul');
  const metrics = PERFORMANCE_YEAR_METRICS;

  const currentMonthData =
    metrics.monthlyGeneration.find((m) => m.month === selectedMonth) || metrics.monthlyGeneration[3];

  // SVG Chart Dimensions
  const chartWidth = 720;
  const chartHeight = 220;
  const padding = { top: 20, right: 30, bottom: 35, left: 45 };
  const graphWidth = chartWidth - padding.left - padding.right;
  const graphHeight = chartHeight - padding.top - padding.bottom;

  const maxMWh = 9500;

  const getX = (idx: number) =>
    padding.left + (idx / (metrics.monthlyGeneration.length - 1)) * graphWidth;
  const getY = (val: number) => padding.top + (1 - val / maxMWh) * graphHeight;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="text-xs font-mono text-emerald-400 flex items-center gap-1.5 mb-1">
            <BarChart3 className="w-3.5 h-3.5" />
            <span>SITE & DECISION INTELLIGENCE MODULE 09 · AUDIT & KPI BENCHMARK</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Performance Analytics, Availability (PAF) & Energy Loss Auditing
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Historical generation trends, Central Electricity Authority (CEA) availability benchmarks, water utilization efficiency, and energy loss waterfall accounting.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
          <span>Fiscal Year 2025-26</span>
          <span className="text-slate-600">·</span>
          <span className="text-emerald-400 font-bold">71.9 GWh Total Generated</span>
        </div>
      </div>

      {/* Primary Key Performance Indicators */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <MetricCard
          label="Plant Load Factor (PLF)"
          value={metrics.plantLoadFactorPLF}
          unit="%"
          subLabel="Industry Avg"
          subValue="58.2% Himalayan"
          status="nominal"
          icon={<Zap className="w-3.5 h-3.5 text-sky-400" />}
          trend={{ direction: 'up', value: '+10.2% Above' }}
        />
        <MetricCard
          label="Availability Factor (PAF)"
          value={metrics.plantAvailabilityFactorPAF}
          unit="%"
          subLabel="CEA Target"
          subValue="85.0% Norm"
          status="nominal"
          icon={<ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />}
          trend={{ direction: 'up', value: '+9.2% Incentive' }}
        />
        <MetricCard
          label="Water Utilization Factor"
          value={metrics.waterUtilizationEfficiency}
          unit="%"
          subLabel="Spill Loss"
          subValue="8.2% High Flood"
          status="nominal"
          icon={<Activity className="w-3.5 h-3.5 text-blue-400" />}
        />
        <MetricCard
          label="Annual Gross Generation"
          value={metrics.totalGenerationGWh}
          unit="GWh"
          subLabel="Target PPA"
          subValue="70.5 GWh"
          status="nominal"
          icon={<TrendingUp className="w-3.5 h-3.5 text-emerald-400" />}
          trend={{ direction: 'up', value: '+1.4 GWh' }}
        />
        <MetricCard
          label="Silt Forced Outage"
          value={metrics.annualOutageHours.highSedimentForcedShutdown}
          unit="hrs"
          subLabel="Unscheduled"
          subValue="2.1% of Year"
          status="warning"
          icon={<Clock className="w-3.5 h-3.5 text-amber-400" />}
        />
        <MetricCard
          label="Auxiliary Consumption"
          value="0.82"
          unit="%"
          subLabel="CEA Norm Limit"
          subValue="1.00% Max"
          status="nominal"
          icon={<ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />}
        />
      </div>

      {/* Main Monthly Generation Curve Chart */}
      <div className="bg-[#0c1424] border border-slate-800 rounded-xl p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-sm font-semibold text-white">Monthly Generation: Target vs Actual (MWh)</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Reflecting Himalayan seasonal hydrology: peak monsoon runoff (Jun - Sep) vs lean glacial winter flow (Dec - Feb)
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-emerald-400 inline-block" />
              <span className="text-slate-300">Actual MWh</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-slate-500 border-dashed inline-block" />
              <span className="text-slate-400">Design PPA Target</span>
            </div>
          </div>
        </div>

        {/* SVG Chart */}
        <div className="py-4">
          <svg
            viewBox={`0 0 ${chartWidth} ${chartHeight}`}
            className="w-full h-auto overflow-visible select-none"
          >
            {/* Horizontal Grid lines */}
            {[2000, 4000, 6000, 8000].map((val) => (
              <g key={val}>
                <line
                  x1={padding.left}
                  y1={getY(val)}
                  x2={chartWidth - padding.right}
                  y2={getY(val)}
                  stroke="#1e293b"
                  strokeDasharray="3 3"
                />
                <text
                  x={padding.left - 8}
                  y={getY(val) + 3}
                  textAnchor="end"
                  fill="#64748b"
                  fontSize="10"
                  fontFamily="monospace"
                >
                  {val / 1000}k
                </text>
              </g>
            ))}

            {/* Target Line */}
            <polyline
              points={metrics.monthlyGeneration
                .map((d, i) => `${getX(i)},${getY(d.targetMWh)}`)
                .join(' ')}
              fill="none"
              stroke="#64748b"
              strokeWidth="1.5"
              strokeDasharray="4 4"
            />

            {/* Actual Line */}
            <polyline
              points={metrics.monthlyGeneration
                .map((d, i) => `${getX(i)},${getY(d.generationMWh)}`)
                .join(' ')}
              fill="none"
              stroke="#10b981"
              strokeWidth="2.5"
            />

            {/* Data Points */}
            {metrics.monthlyGeneration.map((d, i) => {
              const isSelected = selectedMonth === d.month;
              return (
                <g
                  key={d.month}
                  onClick={() => setSelectedMonth(d.month)}
                  className="cursor-pointer"
                >
                  <circle
                    cx={getX(i)}
                    cy={getY(d.generationMWh)}
                    r={isSelected ? 6 : 3.5}
                    fill={isSelected ? '#ffffff' : '#10b981'}
                    stroke="#0a101f"
                    strokeWidth="2"
                  />
                  <text
                    x={getX(i)}
                    y={chartHeight - 10}
                    textAnchor="middle"
                    fill={isSelected ? '#f8fafc' : '#64748b'}
                    fontSize="10"
                    fontFamily="monospace"
                    fontWeight={isSelected ? 'bold' : 'normal'}
                  >
                    {d.month}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Selected Month Detail Strip */}
        <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white bg-slate-800 px-2 py-0.5 rounded text-[11px]">
              {currentMonthData.month.toUpperCase()} PERFORMANCE
            </span>
            <span className="text-slate-400 font-sans">
              Generated: <strong className="text-emerald-400 font-mono">{currentMonthData.generationMWh} MWh</strong> vs Target {currentMonthData.targetMWh} MWh
            </span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span>PLF: <strong className="text-white">{currentMonthData.plf}%</strong></span>
            <span>Avg Silt: <strong className="text-amber-400">{currentMonthData.sedimentAvgNTU} NTU</strong></span>
          </div>
        </div>
      </div>

      {/* Grid: Loss Waterfall & Outage Hours Accounting */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Energy Loss Waterfall (7 cols) */}
        <div className="lg:col-span-7 bg-[#0c1424] border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <h3 className="text-sm font-semibold text-white">Annual Generation Loss Accounting</h3>
            <span className="text-xs text-slate-500 font-mono">Waterfall Matrix</span>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Turbine Runner Hydro-Abrasive Wear Loss</span>
                <span className="font-mono text-rose-400 font-bold">-2,140 MWh (2.8%)</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                <div className="bg-rose-400 h-1.5 rounded-full" style={{ width: '42%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Spillway High-Flood Unutilized Discharge</span>
                <span className="font-mono text-amber-400 font-bold">-1,480 MWh (1.9%)</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                <div className="bg-amber-400 h-1.5 rounded-full" style={{ width: '29%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Penstock & Water Conductor Friction Head Loss</span>
                <span className="font-mono text-sky-400 font-bold">-890 MWh (1.2%)</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                <div className="bg-sky-400 h-1.5 rounded-full" style={{ width: '18%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Grid Evacuation Outage (State Grid Tripping)</span>
                <span className="font-mono text-slate-400 font-bold">-540 MWh (0.7%)</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                <div className="bg-slate-500 h-1.5 rounded-full" style={{ width: '11%' }} />
              </div>
            </div>
          </div>
        </div>

        {/* Outage Breakdown (5 cols) */}
        <div className="lg:col-span-5 bg-[#0c1424] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <h3 className="text-sm font-semibold text-white">Outage Hours Classification</h3>
              <Clock className="w-4 h-4 text-slate-500" />
            </div>

            <div className="space-y-2.5 text-xs font-mono">
              <div className="p-2.5 rounded bg-slate-900 border border-slate-800 flex justify-between items-center">
                <span className="text-slate-300">Planned Overhaul / Overhaul:</span>
                <span className="text-emerald-400 font-bold">240 hrs (45.1%)</span>
              </div>
              <div className="p-2.5 rounded bg-slate-900 border border-slate-800 flex justify-between items-center">
                <span className="text-slate-300">High Sediment Shutdown:</span>
                <span className="text-amber-400 font-bold">184 hrs (34.6%)</span>
              </div>
              <div className="p-2.5 rounded bg-slate-900 border border-slate-800 flex justify-between items-center">
                <span className="text-slate-300">State Grid Transmission Failure:</span>
                <span className="text-slate-400 font-bold">72 hrs (13.5%)</span>
              </div>
              <div className="p-2.5 rounded bg-slate-900 border border-slate-800 flex justify-between items-center">
                <span className="text-slate-300">Powerhouse Mechanical Breakdown:</span>
                <span className="text-rose-400 font-bold">36 hrs (6.8%)</span>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 mt-3 flex items-center justify-between text-xs text-slate-500">
            <span>Availability Incentive:</span>
            <span className="text-emerald-400 font-mono font-bold">+₹14.2 Lakh Earned</span>
          </div>
        </div>
      </div>
    </div>
  );
};
