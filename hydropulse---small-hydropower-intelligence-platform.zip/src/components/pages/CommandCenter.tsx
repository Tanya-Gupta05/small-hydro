import React, { useState } from 'react';
import { Plant, AlertItem } from '../../types/hydro';
import { GENERATION_CURVE_DATA, RECENT_OPERATIONAL_EVENTS } from '../../data/mockHydroData';
import { MetricCard } from '../common/MetricCard';
import { IMAGES } from '../../assets/images/imagePaths';
import {
  Activity,
  Zap,
  Waves,
  Gauge,
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
  Clock,
  Sparkles,
  ChevronRight,
  Sliders,
  CheckCircle2,
  Cpu,
} from 'lucide-react';

interface CommandCenterProps {
  currentPlant: Plant;
  alerts: AlertItem[];
  onAcknowledgeAlert: (id: string) => void;
  onNavigate: (tab: string) => void;
}

export const CommandCenter: React.FC<CommandCenterProps> = ({
  currentPlant,
  alerts,
  onAcknowledgeAlert,
  onNavigate,
}) => {
  const [hoveredPointIndex, setHoveredPointIndex] = useState<number | null>(null);

  // SVG Chart Dimensions
  const chartWidth = 720;
  const chartHeight = 220;
  const padding = { top: 20, right: 30, bottom: 30, left: 40 };
  const graphWidth = chartWidth - padding.left - padding.right;
  const graphHeight = chartHeight - padding.top - padding.bottom;

  const maxMW = 13.5;
  const minMW = 8.0;

  const getX = (index: number) => padding.left + (index / (GENERATION_CURVE_DATA.length - 1)) * graphWidth;
  const getY = (val: number) => padding.top + (1 - (val - minMW) / (maxMW - minMW)) * graphHeight;

  // SVG Paths
  const expectedPoints = GENERATION_CURVE_DATA.map((d, i) => `${getX(i)},${getY(d.expectedMW)}`).join(' ');
  const actualPoints = GENERATION_CURVE_DATA.map((d, i) => `${getX(i)},${getY(d.actualMW)}`).join(' ');
  const areaActual = `${actualPoints} ${getX(GENERATION_CURVE_DATA.length - 1)},${padding.top + graphHeight} ${getX(0)},${padding.top + graphHeight}`;

  const currentHovered = hoveredPointIndex !== null ? GENERATION_CURVE_DATA[hoveredPointIndex] : GENERATION_CURVE_DATA[GENERATION_CURVE_DATA.length - 1];

  return (
    <div className="space-y-6">
      {/* Top Banner / Plant Overview Strip */}
      <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-[#0c1424]">
        <div className="absolute inset-0 z-0 opacity-20 pointer-events-none">
          <img
            src={IMAGES.powerhouseFacility}
            alt="Hydropower facility"
            className="w-full h-full object-cover object-center filter grayscale contrast-125"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0c1424] via-[#0c1424]/90 to-transparent" />
        </div>

        <div className="relative z-10 p-5 lg:p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="text-xs text-sky-400 font-mono tracking-wide mb-1 flex items-center gap-2">
              <span>{currentPlant.state.toUpperCase()}</span>
              <span className="text-slate-600">·</span>
              <span>{currentPlant.basin.toUpperCase()}</span>
              <span className="text-slate-600">·</span>
              <span>COMMISSIONED {currentPlant.commissionYear}</span>
            </div>
            <h1 className="text-xl lg:text-2xl font-bold tracking-tight text-white">
              {currentPlant.name}
            </h1>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl leading-relaxed">
              Run-of-river small hydropower plant delivering clean peak and base generation. Integrated with real-time IEC 62364 abrasive wear mitigation and physics-informed ML dispatch.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="px-3 py-2 rounded bg-slate-900/90 border border-slate-700/80 text-right">
              <div className="text-[10px] text-slate-400 uppercase font-mono">Rated Capacity</div>
              <div className="text-base font-bold font-mono text-white">{currentPlant.capacityMW} MW</div>
            </div>
            <div className="px-3 py-2 rounded bg-slate-900/90 border border-slate-700/80 text-right">
              <div className="text-[10px] text-slate-400 uppercase font-mono">Active Power</div>
              <div className="text-base font-bold font-mono text-sky-400">{currentPlant.currentPowerMW} MW</div>
            </div>
            <button
              onClick={() => onNavigate('operating_opt')}
              className="h-10 px-4 rounded bg-sky-500 hover:bg-sky-400 text-slate-950 font-semibold text-xs transition-colors flex items-center gap-1.5 shadow-sm"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>Optimize Dispatch</span>
            </button>
          </div>
        </div>
      </div>

      {/* Primary Key Operational Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <MetricCard
          label="Active Generation"
          value={currentPlant.currentPowerMW}
          unit="MW"
          subLabel="Expected"
          subValue={`${currentPlant.expectedPowerMW} MW`}
          status="nominal"
          icon={<Zap className="w-3.5 h-3.5 text-sky-400" />}
          trend={{ direction: 'neutral', value: '93.5% Target' }}
        />
        <MetricCard
          label="Turbine Efficiency"
          value="90.1"
          unit="%"
          subLabel="Hill Optimum"
          subValue="93.2%"
          status="advisory"
          icon={<Gauge className="w-3.5 h-3.5 text-purple-400" />}
          trend={{ direction: 'down', value: '-3.1% Wear' }}
        />
        <MetricCard
          label="River Inflow Discharge"
          value={currentPlant.currentFlowM3s}
          unit="m³/s"
          subLabel="Design Flow"
          subValue={`${currentPlant.designDischargeM3s} m³/s`}
          status="nominal"
          icon={<Waves className="w-3.5 h-3.5 text-blue-400" />}
          trend={{ direction: 'up', value: '+0.4 m³/s' }}
        />
        <MetricCard
          label="Net Hydraulic Head"
          value={currentPlant.currentHeadM}
          unit="m"
          subLabel="Penstock Loss"
          subValue="1.7 m"
          status="nominal"
          icon={<Activity className="w-3.5 h-3.5 text-emerald-400" />}
        />
        <MetricCard
          label="Catchment Silt Turbidity"
          value={currentPlant.currentTurbidityNTU}
          unit="NTU"
          subLabel="Quartz Ratio"
          subValue={`${currentPlant.quartzContentPercent}%`}
          status={currentPlant.currentTurbidityNTU > 500 ? 'warning' : 'nominal'}
          icon={<AlertTriangle className="w-3.5 h-3.5 text-amber-400" />}
          trend={{ direction: 'up', value: 'Elevated' }}
        />
        <MetricCard
          label="Plant Availability (PAF)"
          value="94.2"
          unit="%"
          subLabel="Grid Code"
          subValue="CEA Norm 85%"
          status="nominal"
          icon={<ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />}
          trend={{ direction: 'up', value: '+9.2% Above' }}
        />
      </div>

      {/* Main Dual Grid: Generation Curves & Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Expected vs Actual Generation Curve (7 Cols) */}
        <div className="lg:col-span-7 bg-[#0c1424] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-sky-400" />
                <h3 className="text-sm font-semibold text-white">Expected vs Actual Generation Curve</h3>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                24-Hour telemetry tracking physics-informed power vs actual turbine dispatch
              </p>
            </div>

            {/* Live Crosshair Readout */}
            <div className="flex items-center gap-4 text-xs font-mono">
              <div>
                <span className="text-slate-500 mr-1.5">Time:</span>
                <span className="text-white font-semibold">{currentHovered.time}</span>
              </div>
              <div>
                <span className="text-slate-500 mr-1.5">Actual:</span>
                <span className="text-sky-400 font-semibold">{currentHovered.actualMW} MW</span>
              </div>
              <div>
                <span className="text-slate-500 mr-1.5">Loss:</span>
                <span className="text-rose-400 font-semibold">{currentHovered.lossMW} MW</span>
              </div>
            </div>
          </div>

          {/* SVG Interactive Visualizer */}
          <div className="py-4">
            <svg
              viewBox={`0 0 ${chartWidth} ${chartHeight}`}
              className="w-full h-auto overflow-visible select-none"
            >
              <defs>
                <linearGradient id="actualGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#0284c7" stopOpacity="0.35" />
                  <stop offset="100%" stopColor="#0284c7" stopOpacity="0.02" />
                </linearGradient>
              </defs>

              {/* Horizontal Grid lines */}
              {[8, 9, 10, 11, 12, 13].map((val) => (
                <g key={val}>
                  <line
                    x1={padding.left}
                    y1={getY(val)}
                    x2={padding.left + graphWidth}
                    y2={getY(val)}
                    stroke="#1e293b"
                    strokeDasharray="3 3"
                  />
                  <text
                    x={padding.left - 8}
                    y={getY(val) + 3}
                    textAnchor="end"
                    fill="#64748b"
                    fontSize="10"
                    fontFamily="monospace"
                  >
                    {val}M
                  </text>
                </g>
              ))}

              {/* Area fill for actual */}
              <polygon points={areaActual} fill="url(#actualGrad)" />

              {/* Expected Line (Dashed Purple/Slate) */}
              <polyline
                points={expectedPoints}
                fill="none"
                stroke="#a855f7"
                strokeWidth="2"
                strokeDasharray="4 4"
              />

              {/* Actual Generation Line (Solid Sky Blue) */}
              <polyline
                points={actualPoints}
                fill="none"
                stroke="#38bdf8"
                strokeWidth="2.5"
              />

              {/* Interactive Dots and Crosshair */}
              {GENERATION_CURVE_DATA.map((d, i) => (
                <g
                  key={i}
                  onMouseEnter={() => setHoveredPointIndex(i)}
                  className="cursor-pointer"
                >
                  <circle
                    cx={getX(i)}
                    cy={getY(d.actualMW)}
                    r={hoveredPointIndex === i ? 5 : 3}
                    fill={hoveredPointIndex === i ? '#ffffff' : '#38bdf8'}
                    stroke="#0a101f"
                    strokeWidth="2"
                  />
                  <text
                    x={getX(i)}
                    y={chartHeight - 8}
                    textAnchor="middle"
                    fill={hoveredPointIndex === i ? '#f8fafc' : '#64748b'}
                    fontSize="10"
                    fontFamily="monospace"
                  >
                    {d.time}
                  </text>
                </g>
              ))}

              {hoveredPointIndex !== null && (
                <line
                  x1={getX(hoveredPointIndex)}
                  y1={padding.top}
                  x2={getX(hoveredPointIndex)}
                  y2={padding.top + graphHeight}
                  stroke="#38bdf8"
                  strokeWidth="1"
                  strokeDasharray="2 2"
                />
              )}
            </svg>
          </div>

          <div className="pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-xs text-slate-400 gap-2">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-sky-400 inline-block" />
                <span>Actual Dispatch</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-purple-400 border-dashed inline-block" />
                <span>Ideal Physics Potential</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 bg-rose-500/20 border border-rose-500/40 rounded-xs inline-block" />
                <span>Erosion Gap (~0.6 MW)</span>
              </div>
            </div>

            <button
              onClick={() => onNavigate('performance')}
              className="text-sky-400 hover:text-sky-300 font-medium flex items-center gap-1 transition-colors"
            >
              <span>Detailed Analytics</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Right Column: Active Risks & Alerts Panel (5 Cols) */}
        <div className="lg:col-span-5 bg-[#0c1424] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <h3 className="text-sm font-semibold text-white">Current Risk & Advisory Alerts</h3>
            </div>
            <span className="text-xs font-mono text-slate-400">
              {alerts.filter((a) => !a.acknowledged).length} Active
            </span>
          </div>

          <div className="space-y-3 py-3 flex-1 overflow-y-auto max-h-[300px]">
            {alerts.map((alert) => (
              <div
                key={alert.id}
                className={`p-3 rounded-lg border text-xs transition-colors ${
                  alert.level === 'critical'
                    ? 'bg-rose-950/20 border-rose-800/60'
                    : alert.level === 'warning'
                    ? 'bg-amber-950/20 border-amber-800/60'
                    : 'bg-slate-900 border-slate-800'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-0.5">
                    <div className="font-semibold text-white flex items-center gap-1.5">
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          alert.level === 'critical'
                            ? 'bg-rose-500 animate-ping'
                            : alert.level === 'warning'
                            ? 'bg-amber-400'
                            : 'bg-sky-400'
                        }`}
                      />
                      <span>{alert.title}</span>
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      <span>{alert.source}</span>
                      {alert.unit && <span> · {alert.unit}</span>}
                    </div>
                  </div>

                  <span className="text-[10px] font-mono text-slate-500 shrink-0">
                    {alert.timestamp}
                  </span>
                </div>

                <p className="text-slate-300 mt-2 text-[11px] leading-relaxed">
                  {alert.details}
                </p>

                <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2">
                  <div className="text-[10px] text-amber-300 truncate max-w-[240px]">
                    <strong>Mitigation:</strong> {alert.suggestedMitigation}
                  </div>

                  <button
                    onClick={() => onAcknowledgeAlert(alert.id)}
                    className={`px-2 py-1 rounded text-[10px] font-mono transition-colors shrink-0 ${
                      alert.acknowledged
                        ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-800/60'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                    }`}
                  >
                    {alert.acknowledged ? '✓ Acknowledged' : 'Acknowledge'}
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
            <span className="text-slate-500">Automated SOP compliance protocol</span>
            <button
              onClick={() => onNavigate('resilience')}
              className="text-rose-400 hover:text-rose-300 font-medium flex items-center gap-1 transition-colors"
            >
              <span>Resilience Engine</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Grid: Recent Operational Events & Intelligence Engines Rapid Gateway */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Recent Operational Events (7 cols) */}
        <div className="lg:col-span-7 bg-[#0c1424] border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-400" />
              <h3 className="text-sm font-semibold text-white">Recent Operational SCADA & ML Events</h3>
            </div>
            <span className="text-xs text-slate-500 font-mono">Last 24 Hours</span>
          </div>

          <div className="divide-y divide-slate-800/60">
            {RECENT_OPERATIONAL_EVENTS.map((event) => (
              <div key={event.id} className="py-2.5 flex items-start justify-between gap-3 text-xs">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-200">{event.title}</span>
                    <span className="text-[10px] font-mono text-slate-500 uppercase">
                      [{event.type}]
                    </span>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    {event.description}
                  </p>
                </div>
                <span className="font-mono text-[10px] text-slate-500 shrink-0">
                  {event.timestamp}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Intelligence Engines Quick Navigation Gateway (5 cols) */}
        <div className="lg:col-span-5 bg-[#0c1424] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 pb-3 border-b border-slate-800 mb-3">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <h3 className="text-sm font-semibold text-white">HydroPulse Intelligence Engines</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                onClick={() => onNavigate('sediment')}
                className="p-3 text-left rounded-lg bg-slate-900 border border-slate-800 hover:border-amber-700/60 hover:bg-slate-850 transition-all group"
              >
                <div className="flex items-center justify-between mb-1">
                  <Waves className="w-4 h-4 text-amber-400" />
                  <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-amber-400 transition-colors" />
                </div>
                <div className="font-semibold text-slate-200 text-xs">Sediment & Erosion</div>
                <div className="text-[10px] text-slate-500">72h Forecast + Silt Loss</div>
              </button>

              <button
                onClick={() => onNavigate('turbine_ai')}
                className="p-3 text-left rounded-lg bg-slate-900 border border-slate-800 hover:border-purple-700/60 hover:bg-slate-850 transition-all group"
              >
                <div className="flex items-center justify-between mb-1">
                  <Gauge className="w-4 h-4 text-purple-400" />
                  <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-purple-400 transition-colors" />
                </div>
                <div className="font-semibold text-slate-200 text-xs">Turbine Intelligence</div>
                <div className="text-[10px] text-slate-500">Hill Chart & FFT Vibration</div>
              </button>

              <button
                onClick={() => onNavigate('operating_opt')}
                className="p-3 text-left rounded-lg bg-slate-900 border border-slate-800 hover:border-emerald-700/60 hover:bg-slate-850 transition-all group"
              >
                <div className="flex items-center justify-between mb-1">
                  <Sliders className="w-4 h-4 text-emerald-400" />
                  <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-emerald-400 transition-colors" />
                </div>
                <div className="font-semibold text-slate-200 text-xs">Operating Optimization</div>
                <div className="text-[10px] text-slate-500">+0.36 MW Dynamic Uplift</div>
              </button>

              <button
                onClick={() => onNavigate('what_if')}
                className="p-3 text-left rounded-lg bg-slate-900 border border-slate-800 hover:border-sky-700/60 hover:bg-slate-850 transition-all group"
              >
                <div className="flex items-center justify-between mb-1">
                  <Cpu className="w-3.5 h-3.5 text-sky-400" />
                  <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-sky-400 transition-colors" />
                </div>
                <div className="font-semibold text-slate-200 text-xs">What-If Simulator</div>
                <div className="text-[10px] text-slate-500">Live Navier-Stokes Sandbox</div>
              </button>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 mt-3 flex items-center justify-between text-xs text-slate-500">
            <span>ML Pipeline: XGBoost + Random Forest</span>
            <button
              onClick={() => onNavigate('ml_pipeline')}
              className="text-purple-400 hover:text-purple-300 font-medium flex items-center gap-1"
            >
              <span>View 3-Model Flow</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
