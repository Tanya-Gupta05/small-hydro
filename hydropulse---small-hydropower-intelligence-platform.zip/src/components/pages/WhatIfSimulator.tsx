import React, { useState } from 'react';
import { Plant, WhatIfInputs } from '../../types/hydro';
import { runWhatIfSimulation } from '../../utils/physicsEngine';
import { MetricCard } from '../common/MetricCard';
import {
  Cpu,
  Sliders,
  Zap,
  TrendingUp,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Waves,
  Gauge,
  Clock,
  ShieldAlert,
} from 'lucide-react';

interface WhatIfSimulatorProps {
  currentPlant: Plant;
}

export const WhatIfSimulator: React.FC<WhatIfSimulatorProps> = ({ currentPlant }) => {
  const initialInputs: WhatIfInputs = {
    rainfallMm: 12.0,
    inflowM3s: currentPlant.currentFlowM3s,
    grossHeadM: currentPlant.netHeadM,
    tailwaterRiseM: 0.2,
    sedimentNTU: currentPlant.currentTurbidityNTU,
    runnerErosionPct: 12,
    guideVanePercent: 86,
    quartzRatio: currentPlant.quartzContentPercent / 100,
  };

  const [inputs, setInputs] = useState<WhatIfInputs>(initialInputs);

  const outputs = runWhatIfSimulation(inputs);

  // Preset scenarios
  const applyPreset = (name: string) => {
    switch (name) {
      case 'monsoon':
        setInputs({
          rainfallMm: 38.0,
          inflowM3s: 18.5,
          grossHeadM: currentPlant.netHeadM - 2.5,
          tailwaterRiseM: 1.8,
          sedimentNTU: 2400,
          runnerErosionPct: 18,
          guideVanePercent: 92,
          quartzRatio: 0.82,
        });
        break;
      case 'lean':
        setInputs({
          rainfallMm: 0.0,
          inflowM3s: 3.4,
          grossHeadM: currentPlant.netHeadM + 1.2,
          tailwaterRiseM: 0.0,
          sedimentNTU: 45,
          runnerErosionPct: 8,
          guideVanePercent: 48,
          quartzRatio: 0.65,
        });
        break;
      case 'cavitation':
        setInputs({
          rainfallMm: 8.0,
          inflowM3s: 14.0,
          grossHeadM: 132.0,
          tailwaterRiseM: 0.1,
          sedimentNTU: 320,
          runnerErosionPct: 30,
          guideVanePercent: 98,
          quartzRatio: 0.75,
        });
        break;
      case 'pristine':
        setInputs({
          rainfallMm: 6.0,
          inflowM3s: 12.4,
          grossHeadM: currentPlant.netHeadM,
          tailwaterRiseM: 0.1,
          sedimentNTU: 120,
          runnerErosionPct: 0,
          guideVanePercent: 85,
          quartzRatio: 0.70,
        });
        break;
      case 'reset':
      default:
        setInputs(initialInputs);
        break;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="text-xs font-mono text-purple-400 flex items-center gap-1.5 mb-1">
            <Cpu className="w-3.5 h-3.5" />
            <span>SITE & DECISION INTELLIGENCE MODULE 06 · LIVE HYDRAULIC SANDBOX</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            What-If Hydro Scenario Simulator & Dynamic Physics Solver
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Simulate non-linear interactions between catchment precipitation, head losses, tailwater surges, quartz silt abrasion, and runner blade degradation on net grid generation.
          </p>
        </div>

        {/* Presets Button Bar */}
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => applyPreset('monsoon')}
            className="px-2.5 py-1.5 rounded text-xs font-mono bg-slate-900 border border-slate-800 text-amber-300 hover:border-amber-700 transition-colors"
          >
            Monsoon Surge
          </button>
          <button
            onClick={() => applyPreset('lean')}
            className="px-2.5 py-1.5 rounded text-xs font-mono bg-slate-900 border border-slate-800 text-sky-300 hover:border-sky-700 transition-colors"
          >
            Winter Lean Flow
          </button>
          <button
            onClick={() => applyPreset('cavitation')}
            className="px-2.5 py-1.5 rounded text-xs font-mono bg-slate-900 border border-slate-800 text-rose-300 hover:border-rose-700 transition-colors"
          >
            Cavitation Hazard
          </button>
          <button
            onClick={() => applyPreset('pristine')}
            className="px-2.5 py-1.5 rounded text-xs font-mono bg-slate-900 border border-slate-800 text-emerald-300 hover:border-emerald-700 transition-colors"
          >
            Post-Overhaul Pristine
          </button>
          <button
            onClick={() => applyPreset('reset')}
            className="p-1.5 rounded text-xs font-mono bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-colors"
            title="Reset Defaults"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Output Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <MetricCard
          label="Simulated Power Output"
          value={outputs.electricalPowerMW}
          unit="MW"
          subLabel="Ideal Physics"
          subValue={`${outputs.expectedPowerMW} MW`}
          status={outputs.electricalPowerMW > 10 ? 'nominal' : 'warning'}
          icon={<Zap className="w-3.5 h-3.5 text-sky-400" />}
          trend={{ direction: outputs.powerDeltaMW >= 0 ? 'up' : 'down', value: `${outputs.powerDeltaMW} MW Delta` }}
        />
        <MetricCard
          label="Overall Plant Efficiency"
          value={outputs.overallEfficiency}
          unit="%"
          subLabel="Mechanical η"
          subValue={`${outputs.mechanicalEfficiency}%`}
          status={outputs.overallEfficiency > 88 ? 'nominal' : 'warning'}
          icon={<Gauge className="w-3.5 h-3.5 text-purple-400" />}
        />
        <MetricCard
          label="Cavitation Parameter σ"
          value={outputs.cavitationSigma}
          unit=""
          subLabel="Risk Grade"
          subValue={outputs.cavitationRisk}
          status={outputs.cavitationRisk === 'Safe' ? 'nominal' : 'critical'}
          icon={<AlertTriangle className="w-3.5 h-3.5 text-rose-400" />}
        />
        <MetricCard
          label="IEC 62364 Erosion Rate"
          value={outputs.erosionRateMmPer1000h}
          unit="mm/1k h"
          subLabel="Wear Velocity"
          subValue={`${outputs.estimatedBladeLifeMonths} Mo Life`}
          status={outputs.erosionRateMmPer1000h > 0.25 ? 'warning' : 'nominal'}
          icon={<Waves className="w-3.5 h-3.5 text-amber-400" />}
        />
        <MetricCard
          label="Net Penstock Head"
          value={outputs.netHeadM}
          unit="m"
          subLabel="Effective Flow"
          subValue={`${outputs.effectiveFlowM3s} m³/s`}
          status="nominal"
          icon={<Sliders className="w-3.5 h-3.5 text-blue-400" />}
        />
        <MetricCard
          label="Simulated Daily Revenue"
          value={`₹${(outputs.revenuePerDayINR / 100000).toFixed(2)}L`}
          unit=""
          subLabel="Loss to Wear"
          subValue={`-₹${outputs.dailyRevenueLossINR.toLocaleString()}`}
          status="nominal"
          icon={<TrendingUp className="w-3.5 h-3.5 text-emerald-400" />}
        />
      </div>

      {/* Main Dual Grid: Sliders on Left & Simulation Results on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sliders Form (6 cols) */}
        <div className="lg:col-span-6 bg-[#0c1424] border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-semibold text-white">Hydraulic & Catchment Sliders</h3>
            <span className="text-xs font-mono text-purple-400">Euler Turbine Formulation</span>
          </div>

          {/* Slider 1: Inflow */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">River Inflow Discharge (Q)</span>
              <span className="font-mono text-sky-400 font-bold">{inputs.inflowM3s} m³/s</span>
            </div>
            <input
              type="range"
              min="2.0"
              max="24.0"
              step="0.2"
              value={inputs.inflowM3s}
              onChange={(e) => setInputs({ ...inputs, inflowM3s: Number(e.target.value) })}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
            />
          </div>

          {/* Slider 2: Gross Head */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">Gross Hydraulic Head (H_gross)</span>
              <span className="font-mono text-blue-400 font-bold">{inputs.grossHeadM} m</span>
            </div>
            <input
              type="range"
              min="80"
              max="145"
              step="0.5"
              value={inputs.grossHeadM}
              onChange={(e) => setInputs({ ...inputs, grossHeadM: Number(e.target.value) })}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-400"
            />
          </div>

          {/* Slider 3: Tailwater Rise */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">Tailwater Rise / Hydraulic Surcharge</span>
              <span className="font-mono text-amber-400 font-bold">{inputs.tailwaterRiseM} m</span>
            </div>
            <input
              type="range"
              min="0.0"
              max="4.0"
              step="0.1"
              value={inputs.tailwaterRiseM}
              onChange={(e) => setInputs({ ...inputs, tailwaterRiseM: Number(e.target.value) })}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
            />
          </div>

          {/* Slider 4: Sediment Turbidity */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">Sediment Turbidity (NTU)</span>
              <span className="font-mono text-amber-400 font-bold">{inputs.sedimentNTU} NTU</span>
            </div>
            <input
              type="range"
              min="20"
              max="3500"
              step="20"
              value={inputs.sedimentNTU}
              onChange={(e) => setInputs({ ...inputs, sedimentNTU: Number(e.target.value) })}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
            />
          </div>

          {/* Slider 5: Runner Blade Degradation */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">Runner Abrasive Wear / Roughness</span>
              <span className="font-mono text-rose-400 font-bold">{inputs.runnerErosionPct}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="50"
              step="1"
              value={inputs.runnerErosionPct}
              onChange={(e) => setInputs({ ...inputs, runnerErosionPct: Number(e.target.value) })}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-400"
            />
          </div>

          {/* Slider 6: Guide Vane Opening */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">Guide Vane Opening (GVO %)</span>
              <span className="font-mono text-emerald-400 font-bold">{inputs.guideVanePercent}%</span>
            </div>
            <input
              type="range"
              min="30"
              max="100"
              step="1"
              value={inputs.guideVanePercent}
              onChange={(e) => setInputs({ ...inputs, guideVanePercent: Number(e.target.value) })}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-400"
            />
          </div>
        </div>

        {/* Right: Detailed Physics Decomposition Card (6 cols) */}
        <div className="lg:col-span-6 bg-[#0c1424] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-sm font-semibold text-white">Mathematical Solution & Loss Breakdown</h3>
              <span className="text-xs font-mono text-sky-400 font-bold">P = ρ·g·Q·H·η</span>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex justify-between items-center font-mono">
                <span className="text-slate-400 font-sans">Gross Hydraulic Potential:</span>
                <span className="text-white font-bold">
                  {((1000 * 9.81 * inputs.inflowM3s * inputs.grossHeadM) / 1e6).toFixed(2)} MW
                </span>
              </div>

              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex justify-between items-center font-mono">
                <span className="text-slate-400 font-sans">Penstock Darcy Friction Loss:</span>
                <span className="text-rose-400 font-bold">
                  -{(inputs.grossHeadM - outputs.netHeadM).toFixed(2)} m Head Loss
                </span>
              </div>

              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex justify-between items-center font-mono">
                <span className="text-slate-400 font-sans">Abrasive Runner Degradation Gap:</span>
                <span className="text-amber-400 font-bold">
                  {Math.abs(outputs.powerDeltaMW)} MW ({((Math.abs(outputs.powerDeltaMW) / outputs.expectedPowerMW) * 100).toFixed(1)}%)
                </span>
              </div>

              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex justify-between items-center font-mono">
                <span className="text-slate-400 font-sans">Thoma Cavitation Assessment:</span>
                <span
                  className={`font-bold ${
                    outputs.cavitationRisk === 'Safe' ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {outputs.cavitationRisk.toUpperCase()} (σ = {outputs.cavitationSigma})
                </span>
              </div>

              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex justify-between items-center font-mono">
                <span className="text-slate-400 font-sans">Remaining Runner Blade Life:</span>
                <span className="text-sky-400 font-bold">
                  ~{outputs.estimatedBladeLifeMonths} Months Continuous
                </span>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 mt-4 flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>CEA Standard Compliance Checked</span>
            <span className="text-emerald-400 font-bold">INVARIANTS SATISFIED</span>
          </div>
        </div>
      </div>
    </div>
  );
};
