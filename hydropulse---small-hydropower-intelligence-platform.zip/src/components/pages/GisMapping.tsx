import React, { useState } from 'react';
import { Plant } from '../../types/hydro';
import { MetricCard } from '../common/MetricCard';
import { IMAGES } from '../../assets/images/imagePaths';
import {
  MapPin,
  Layers,
  Eye,
  EyeOff,
  Navigation,
  Compass,
  Maximize2,
  ZoomIn,
  ZoomOut,
  Info,
  Waves,
  Mountain,
} from 'lucide-react';

interface GisMappingProps {
  currentPlant: Plant;
}

interface GisFeaturePoint {
  id: string;
  name: string;
  category: 'intake' | 'desilting' | 'tunnel' | 'penstock' | 'powerhouse' | 'gauge';
  x: number;
  y: number;
  elevationM: number;
  telemetry: string;
  status: 'nominal' | 'warning' | 'alert';
}

export const GisMapping: React.FC<GisMappingProps> = ({ currentPlant }) => {
  const [showRiver, setShowRiver] = useState<boolean>(true);
  const [showContours, setShowContours] = useState<boolean>(true);
  const [showInfrastructure, setShowInfrastructure] = useState<boolean>(true);
  const [showRiskHeatmap, setShowRiskHeatmap] = useState<boolean>(true);
  const [selectedPointId, setSelectedPointId] = useState<string>('pt-powerhouse');

  const infrastructurePoints: GisFeaturePoint[] = [
    {
      id: 'pt-gauge-1',
      name: 'Upstream Catchment Gauging Station #1 (GS-01)',
      category: 'gauge',
      x: 140,
      y: 70,
      elevationM: 1840,
      telemetry: 'Discharge: 14.8 m³/s · Turbidity: 620 NTU · Rain: 18.2 mm/6h',
      status: 'warning',
    },
    {
      id: 'pt-intake',
      name: 'River Diversion Weir & Intake Barrage',
      category: 'intake',
      x: 280,
      y: 120,
      elevationM: 1358.5,
      telemetry: 'Water Level: 1358.2m · Trash Rack ΔH: 0.18m · Gate: 65% Open',
      status: 'nominal',
    },
    {
      id: 'pt-desilting',
      name: 'Twin-Chamber Dufour Desilting Basin',
      category: 'desilting',
      x: 370,
      y: 160,
      elevationM: 1356.0,
      telemetry: 'Settling Velocity: 0.22 m/s · Silt Sump Depth: 1.4m · Hopper: Bleeding',
      status: 'nominal',
    },
    {
      id: 'pt-tunnel',
      name: 'Headrace Tunnel (HRT - 2.8 km D-Shaped)',
      category: 'tunnel',
      x: 480,
      y: 200,
      elevationM: 1352.0,
      telemetry: 'Flow Velocity: 2.1 m/s · Friction Loss: 1.15m · Internal P: 2.4 bar',
      status: 'nominal',
    },
    {
      id: 'pt-surge',
      name: 'Restricted Orifice Surge Tank',
      category: 'tunnel',
      x: 580,
      y: 230,
      elevationM: 1365.0,
      telemetry: 'Surge Water Oscillation: ±0.35m · Air Vent: Clear',
      status: 'nominal',
    },
    {
      id: 'pt-penstock',
      name: 'High-Pressure Steel Surface Penstock (118.5m Drop)',
      category: 'penstock',
      x: 640,
      y: 270,
      elevationM: 1290.0,
      telemetry: 'Ultrasonic Flow: 11.2 m³/s · Static Head: 11.6 bar · Acoustic: Nominal',
      status: 'nominal',
    },
    {
      id: 'pt-powerhouse',
      name: 'Surface Powerhouse & Switchyard',
      category: 'powerhouse',
      x: 710,
      y: 330,
      elevationM: 1240.0,
      telemetry: 'Active Power: 10.42 MW · 2x Francis Units · Bus Voltage: 33 kV',
      status: 'nominal',
    },
    {
      id: 'pt-tailrace',
      name: 'Tailrace Culvert & River Confluence',
      category: 'intake',
      x: 770,
      y: 370,
      elevationM: 1238.2,
      telemetry: 'Tailwater Level: 1238.4m · Submergence: 1.6m · No backflow',
      status: 'nominal',
    },
  ];

  const selectedPoint =
    infrastructurePoints.find((p) => p.id === selectedPointId) || infrastructurePoints[6];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="text-xs font-mono text-sky-400 flex items-center gap-1.5 mb-1">
            <MapPin className="w-3.5 h-3.5" />
            <span>SITE & DECISION INTELLIGENCE MODULE 05 · GIS SPATIAL CATCHMENT</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            GIS Catchment Mapping & Hydro Site Spatial Intelligence
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Interactive multi-layered topographical catchment model tracking river morphology, elevation contours, civil water conductor infrastructure, and landslide hazard zones.
          </p>
        </div>

        {/* Layer Toggles */}
        <div className="flex flex-wrap items-center gap-1.5 bg-slate-900 border border-slate-800 p-1 rounded-lg text-xs font-mono">
          <button
            onClick={() => setShowRiver(!showRiver)}
            className={`px-2.5 py-1 rounded transition-colors ${
              showRiver ? 'bg-sky-950 text-sky-300 border border-sky-800' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            River Reach
          </button>
          <button
            onClick={() => setShowContours(!showContours)}
            className={`px-2.5 py-1 rounded transition-colors ${
              showContours ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            Contours
          </button>
          <button
            onClick={() => setShowInfrastructure(!showInfrastructure)}
            className={`px-2.5 py-1 rounded transition-colors ${
              showInfrastructure ? 'bg-purple-950 text-purple-300 border border-purple-800' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            Civil Assets
          </button>
          <button
            onClick={() => setShowRiskHeatmap(!showRiskHeatmap)}
            className={`px-2.5 py-1 rounded transition-colors ${
              showRiskHeatmap ? 'bg-rose-950 text-rose-300 border border-rose-800' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            Risk Zones
          </button>
        </div>
      </div>

      {/* Primary Key Spatial Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <MetricCard
          label="Catchment Area"
          value={currentPlant.catchmentAreaKm2}
          unit="km²"
          subLabel="Watershed"
          subValue="Steep Himalayan"
          status="nominal"
          icon={<Mountain className="w-3.5 h-3.5 text-slate-400" />}
        />
        <MetricCard
          label="Gross Hydraulic Drop"
          value={currentPlant.netHeadM}
          unit="m"
          subLabel="Intake to Runner"
          subValue="1358.5m - 1240m"
          status="nominal"
          icon={<Navigation className="w-3.5 h-3.5 text-blue-400" />}
        />
        <MetricCard
          label="Headrace Length (HRT)"
          value="2.8"
          unit="km"
          subLabel="Conduit Type"
          subValue="Concrete Lined"
          status="nominal"
          icon={<Layers className="w-3.5 h-3.5 text-purple-400" />}
        />
        <MetricCard
          label="Penstock Length"
          value="260"
          unit="m"
          subLabel="Steel Grade"
          subValue="ASTM A516 Gr.70"
          status="nominal"
          icon={<Waves className="w-3.5 h-3.5 text-sky-400" />}
        />
        <MetricCard
          label="Upstream Gauging"
          value="2"
          unit="Stations"
          subLabel="Lead Time"
          subValue="3.5h Surge Warning"
          status="nominal"
          icon={<MapPin className="w-3.5 h-3.5 text-emerald-400" />}
        />
        <MetricCard
          label="Landslide Vulnerability"
          value="Zone 3"
          unit=""
          subLabel="Slope Stability"
          subValue="Moderate Slope"
          status="warning"
          icon={<Mountain className="w-3.5 h-3.5 text-amber-400" />}
        />
      </div>

      {/* Interactive GIS Vector Map Canvas */}
      <div className="bg-[#0a0f1d] border border-slate-800 rounded-xl overflow-hidden relative">
        {/* Floating Top Control Overlay */}
        <div className="absolute top-3 left-3 z-10 flex items-center gap-2 bg-slate-900/90 border border-slate-800 backdrop-blur-xs px-3 py-1.5 rounded-lg text-xs font-mono">
          <Compass className="w-3.5 h-3.5 text-sky-400 animate-spin-slow" />
          <span className="text-slate-300">
            {currentPlant.coordinates.lat.toFixed(4)}°N, {currentPlant.coordinates.lng.toFixed(4)}°E · WGS84
          </span>
        </div>

        {/* Map Canvas */}
        <div className="w-full h-[440px] relative select-none overflow-hidden bg-[#090d18] bg-grid-pattern">
          <svg
            viewBox="0 0 900 450"
            className="w-full h-full object-cover"
          >
            {/* Topography Elevation Contours */}
            {showContours && (
              <g stroke="#1e293b" fill="none" strokeWidth="1" strokeDasharray="3 3">
                <path d="M 50 40 Q 200 60 400 30 T 850 50" />
                <path d="M 40 90 Q 250 110 500 80 T 870 100" />
                <path d="M 30 160 Q 300 180 550 140 T 880 180" />
                <path d="M 20 240 Q 350 260 620 220 T 890 270" />
                <path d="M 10 320 Q 400 340 700 300 T 900 360" />
                <path d="M 10 400 Q 450 420 750 380 T 900 430" />
              </g>
            )}

            {/* Landslide & Sediment Flash Flood Risk Heatmap polygon */}
            {showRiskHeatmap && (
              <g>
                <polygon
                  points="180,80 320,100 290,180 140,140"
                  fill="#f43f5e"
                  opacity="0.12"
                />
                <text x="210" y="130" fill="#f43f5e" fontSize="10" fontFamily="monospace" opacity="0.8">
                  SLOPE HAZARD (HIGH SILT SCOUR)
                </text>
              </g>
            )}

            {/* River Main Branch & Tributaries */}
            {showRiver && (
              <g fill="none">
                {/* Upper tributary */}
                <path
                  d="M 50 20 Q 120 40 180 70 T 280 120"
                  stroke="#0284c7"
                  strokeWidth="3"
                  opacity="0.6"
                />
                {/* Main Himalayan River Gorge */}
                <path
                  d="M 140 70 Q 220 95 280 120 T 420 220 T 600 310 T 770 370 T 880 420"
                  stroke="#38bdf8"
                  strokeWidth="5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <text x="320" y="240" fill="#38bdf8" fontSize="11" fontFamily="monospace" opacity="0.7">
                  {currentPlant.river.toUpperCase()}
                </text>
              </g>
            )}

            {/* Civil Water Conductor: Headrace Tunnel (HRT) & Penstock */}
            {showInfrastructure && (
              <g fill="none">
                {/* Tunnel Path (dashed orange/purple line cutting through mountain) */}
                <path
                  d="M 370 160 Q 480 200 580 230"
                  stroke="#a855f7"
                  strokeWidth="3.5"
                  strokeDasharray="6 3"
                />
                {/* Surface Penstock */}
                <path
                  d="M 580 230 L 710 330"
                  stroke="#f59e0b"
                  strokeWidth="4"
                  strokeLinecap="round"
                />
                <text x="640" y="260" fill="#f59e0b" fontSize="10" fontFamily="monospace" fontWeight="bold">
                  PENSTOCK (118.5m DROP)
                </text>
              </g>
            )}

            {/* Infrastructure Interactive Nodes */}
            {showInfrastructure &&
              infrastructurePoints.map((pt) => {
                const isSelected = pt.id === selectedPointId;
                return (
                  <g
                    key={pt.id}
                    onClick={() => setSelectedPointId(pt.id)}
                    className="cursor-pointer transition-transform hover:scale-110"
                  >
                    {/* Ring highlight */}
                    {isSelected && (
                      <circle
                        cx={pt.x}
                        cy={pt.y}
                        r={16}
                        fill="none"
                        stroke="#38bdf8"
                        strokeWidth="1.5"
                        strokeDasharray="3 3"
                        className="animate-spin-slow"
                      />
                    )}
                    <circle
                      cx={pt.x}
                      cy={pt.y}
                      r={7}
                      fill={
                        pt.status === 'warning'
                          ? '#f59e0b'
                          : pt.category === 'powerhouse'
                          ? '#38bdf8'
                          : '#a855f7'
                      }
                      stroke="#ffffff"
                      strokeWidth="2"
                    />
                    <text
                      x={pt.x + 10}
                      y={pt.y + 4}
                      fill={isSelected ? '#ffffff' : '#cbd5e1'}
                      fontSize="10"
                      fontWeight={isSelected ? 'bold' : 'normal'}
                      fontFamily="monospace"
                    >
                      {pt.name.split(' ')[0]} ({pt.elevationM}m)
                    </text>
                  </g>
                );
              })}
          </svg>
        </div>

        {/* Selected Asset Bottom Information Drawer */}
        <div className="p-4 bg-[#080d1a] border-t border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-sky-400 bg-sky-950/60 px-2 py-0.5 rounded border border-sky-800/80">
                {selectedPoint.category.toUpperCase()} ASSET
              </span>
              <span className="text-xs text-slate-500">·</span>
              <span className="text-xs text-slate-300 font-semibold">{selectedPoint.name}</span>
            </div>
            <div className="text-xs text-slate-400 font-mono">
              <strong className="text-slate-300">Live SCADA Telemetry:</strong> {selectedPoint.telemetry}
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono shrink-0">
            <div>
              <div className="text-[10px] text-slate-500 uppercase">Elevation AMSL</div>
              <div className="text-white font-bold">{selectedPoint.elevationM} m</div>
            </div>
            <div>
              <div className="text-[10px] text-slate-500 uppercase">Health Status</div>
              <div
                className={`font-bold ${
                  selectedPoint.status === 'warning' ? 'text-amber-400' : 'text-emerald-400'
                }`}
              >
                {selectedPoint.status.toUpperCase()}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
