import React, { useState } from 'react';
import { Plant, TurbineUnitDetail } from '../../types/hydro';
import { TURBINE_UNITS_DATA } from '../../data/mockHydroData';
import { MetricCard } from '../common/MetricCard';
import { IMAGES } from '../../assets/images/imagePaths';
import {
  Gauge,
  Activity,
  AlertTriangle,
  Zap,
  CheckCircle2,
  Wrench,
  Thermometer,
  ShieldCheck,
  Cpu,
} from 'lucide-react';

interface TurbineIntelligenceProps {
  currentPlant: Plant;
}

export const TurbineIntelligence: React.FC<TurbineIntelligenceProps> = ({ currentPlant }) => {
  const [selectedUnitId, setSelectedUnitId] = useState<string>('unit-1');
  const unit = TURBINE_UNITS_DATA.find((u) => u.unitId === selectedUnitId) || TURBINE_UNITS_DATA[0];

  // Hill Chart / Operating Envelope Dimensions
  const hillWidth = 540;
  const hillHeight = 260;
  const hillPadding = { top: 20, right: 30, bottom: 35, left: 45 };

  // Current Unit Operating Point
  // Normalized Head (100 - 130m) & Normalized Flow (4.0 - 7.5 m³/s)
  const normHead = currentPlant.currentHeadM;
  const normFlow = unit.unitId === 'unit-1' ? 5.6 : 5.6;

  const getHillX = (flow: number) =>
    hillPadding.left + ((flow - 3.5) / (8.0 - 3.5)) * (hillWidth - hillPadding.left - hillPadding.right);
  const getHillY = (head: number) =>
    hillPadding.top + (1 - (head - 95) / (135 - 95)) * (hillHeight - hillPadding.top - hillPadding.bottom);

  return (
    <div className="space-y-6">
      {/* Header & Unit Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="text-xs font-mono text-purple-400 flex items-center gap-1.5 mb-1">
            <Gauge className="w-3.5 h-3.5" />
            <span>CORE INTELLIGENCE MODULE 02 · PHYSICS-INFORMED ENVELOPE</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Physics-Informed Turbine Health & Operating Envelope
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Real-time Hill chart operating point tracking, ISO 10816 vibration harmonic decomposition, thermal telemetry, and runner blade abrasive erosion grading.
          </p>
        </div>

        {/* Unit Selector Segmented Buttons */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg">
          {TURBINE_UNITS_DATA.map((u) => (
            <button
              key={u.unitId}
              onClick={() => setSelectedUnitId(u.unitId)}
              className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                selectedUnitId === u.unitId
                  ? 'bg-slate-800 text-white font-semibold shadow-xs border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {u.name}
            </button>
          ))}
        </div>
      </div>

      {/* Primary Key Metrics for Selected Unit */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <MetricCard
          label="Unit Health Score"
          value={unit.healthScore}
          unit="/100"
          subLabel="IEC Condition"
          subValue={unit.healthScore > 80 ? 'Class A (Nominal)' : 'Class B (Wear)'}
          status={unit.healthScore > 80 ? 'nominal' : 'warning'}
          icon={<Gauge className="w-3.5 h-3.5 text-purple-400" />}
          trend={{ direction: unit.healthScore > 80 ? 'neutral' : 'down', value: `${unit.healthScore}% Index` }}
        />
        <MetricCard
          label="Active Unit Output"
          value={unit.currentMW}
          unit="MW"
          subLabel="Rated Power"
          subValue={`${unit.ratedMW} MW`}
          status="nominal"
          icon={<Zap className="w-3.5 h-3.5 text-sky-400" />}
        />
        <MetricCard
          label="Operating Efficiency"
          value={unit.efficiency}
          unit="%"
          subLabel="Ideal Physics"
          subValue="93.2%"
          status={unit.efficiency >= 90 ? 'nominal' : 'warning'}
          icon={<Activity className="w-3.5 h-3.5 text-emerald-400" />}
          trend={{ direction: 'down', value: `-${(93.2 - unit.efficiency).toFixed(1)}% Gap` }}
        />
        <MetricCard
          label="Shaft Rotational Speed"
          value={unit.rpm}
          unit="RPM"
          subLabel="Synchronous"
          subValue="500.0 RPM (50 Hz)"
          status="nominal"
          icon={<Zap className="w-3.5 h-3.5 text-blue-400" />}
        />
        <MetricCard
          label="Peak Vibration RMS"
          value={unit.vibrationSpectrum[2].amplitudeMmS}
          unit="mm/s"
          subLabel="Blade Pass Freq"
          subValue="ISO Limit 4.5"
          status={unit.vibrationSpectrum[2].amplitudeMmS > 3.0 ? 'warning' : 'nominal'}
          icon={<AlertTriangle className="w-3.5 h-3.5 text-amber-400" />}
          trend={{ direction: 'up', value: 'Zone B' }}
        />
        <MetricCard
          label="Runner Overhaul Age"
          value={unit.hoursSinceLastOverhaul}
          unit="hrs"
          subLabel="Erosion Stage"
          subValue={unit.erosionStage.split(' ')[0] + ' ' + unit.erosionStage.split(' ')[1]}
          status={unit.hoursSinceLastOverhaul > 5000 ? 'warning' : 'nominal'}
          icon={<Wrench className="w-3.5 h-3.5 text-slate-400" />}
        />
      </div>

      {/* Main Dual Grid: Physics Hill Chart & FFT Vibration Spectrum */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Physics-Informed Hill Chart Operating Envelope (7 cols) */}
        <div className="lg:col-span-7 bg-[#0c1424] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-purple-400" />
                <h3 className="text-sm font-semibold text-white">
                  Francis Turbine Hill Chart (Operating Envelope)
                </h3>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Head (m) vs Discharge (m³/s) efficiency contours with live operating coordinate
              </p>
            </div>

            <div className="text-xs font-mono text-slate-400">
              Point: <span className="text-white font-semibold">{normHead}m</span> @{' '}
              <span className="text-sky-400 font-semibold">{normFlow} m³/s</span>
            </div>
          </div>

          {/* SVG Hill Chart */}
          <div className="py-4">
            <svg
              viewBox={`0 0 ${hillWidth} ${hillHeight}`}
              className="w-full h-auto overflow-visible select-none"
            >
              {/* Draft Tube Vortex / Cavitation Risk Zone (Low Flow or Low Head) */}
              <polygon
                points={`
                  ${getHillX(3.5)},${getHillY(95)}
                  ${getHillX(4.4)},${getHillY(95)}
                  ${getHillX(4.2)},${getHillY(135)}
                  ${getHillX(3.5)},${getHillY(135)}
                `}
                fill="#881337"
                opacity="0.15"
              />
              <text
                x={getHillX(3.8)}
                y={getHillY(128)}
                fill="#f43f5e"
                fontSize="9"
                fontFamily="monospace"
                opacity="0.8"
                transform={`rotate(-90, ${getHillX(3.8)}, ${getHillY(128)})`}
              >
                VORTEX ROPE ZONE
              </text>

              {/* Grid Lines */}
              {[100, 110, 120, 130].map((h) => (
                <g key={`h-${h}`}>
                  <line
                    x1={hillPadding.left}
                    y1={getHillY(h)}
                    x2={hillWidth - hillPadding.right}
                    y2={getHillY(h)}
                    stroke="#1e293b"
                    strokeDasharray="2 2"
                  />
                  <text
                    x={hillPadding.left - 8}
                    y={getHillY(h) + 3}
                    textAnchor="end"
                    fill="#64748b"
                    fontSize="10"
                    fontFamily="monospace"
                  >
                    {h}m
                  </text>
                </g>
              ))}

              {[4.0, 5.0, 6.0, 7.0].map((q) => (
                <g key={`q-${q}`}>
                  <line
                    x1={getHillX(q)}
                    y1={hillPadding.top}
                    x2={getHillX(q)}
                    y2={hillHeight - hillPadding.bottom}
                    stroke="#1e293b"
                    strokeDasharray="2 2"
                  />
                  <text
                    x={getHillX(q)}
                    y={hillHeight - hillPadding.bottom + 14}
                    textAnchor="middle"
                    fill="#64748b"
                    fontSize="10"
                    fontFamily="monospace"
                  >
                    {q} m³/s
                  </text>
                </g>
              ))}

              {/* Efficiency Iso-Contours */}
              {/* 85% contour */}
              <ellipse
                cx={getHillX(5.8)}
                cy={getHillY(116)}
                rx={150}
                ry={65}
                fill="none"
                stroke="#475569"
                strokeWidth="1.2"
                strokeDasharray="3 3"
              />
              <text x={getHillX(4.5)} y={getHillY(116)} fill="#64748b" fontSize="9" fontFamily="monospace">
                η = 85%
              </text>

              {/* 90% contour */}
              <ellipse
                cx={getHillX(5.9)}
                cy={getHillY(116)}
                rx={110}
                ry={48}
                fill="none"
                stroke="#0284c7"
                strokeWidth="1.5"
              />
              <text x={getHillX(4.9)} y={getHillY(116)} fill="#38bdf8" fontSize="9" fontFamily="monospace">
                η = 90%
              </text>

              {/* 93% Peak Sweet Spot contour */}
              <ellipse
                cx={getHillX(6.1)}
                cy={getHillY(117)}
                rx={60}
                ry={28}
                fill="#0284c7"
                fillOpacity="0.12"
                stroke="#38bdf8"
                strokeWidth="2"
              />
              <text x={getHillX(5.8)} y={getHillY(117)} fill="#38bdf8" fontSize="10" fontWeight="bold" fontFamily="monospace">
                PEAK 93.2%
              </text>

              {/* Current Real-Time Operating Coordinate */}
              <g>
                <circle
                  cx={getHillX(normFlow)}
                  cy={getHillY(normHead)}
                  r={7}
                  fill="#a855f7"
                  stroke="#ffffff"
                  strokeWidth="2"
                  className="animate-pulse"
                />
                <circle
                  cx={getHillX(normFlow)}
                  cy={getHillY(normHead)}
                  r={18}
                  fill="none"
                  stroke="#a855f7"
                  strokeWidth="1"
                  strokeDasharray="2 2"
                />
                <text
                  x={getHillX(normFlow) + 12}
                  y={getHillY(normHead) - 8}
                  fill="#ffffff"
                  fontSize="11"
                  fontWeight="bold"
                  fontFamily="monospace"
                >
                  {unit.unitId.toUpperCase()} NOW ({unit.efficiency}%)
                </text>
              </g>
            </svg>
          </div>

          <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between text-xs text-slate-400 gap-2">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-400 inline-block" />
                <span>Current State</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-full bg-sky-400 inline-block" />
                <span>Peak Efficiency Zone</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500/40 inline-block" />
                <span>Cavitation Risk Margin</span>
              </span>
            </div>
            <div className="text-[11px] font-mono text-purple-300">
              Guidance: Shift flow to 6.1 m³/s for +2.8% recovery
            </div>
          </div>
        </div>

        {/* Right: FFT Vibration Spectrum (ISO 10816-5 Standard) (5 cols) */}
        <div className="lg:col-span-5 bg-[#0c1424] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <span>FFT Vibration Harmonic Spectrum</span>
                <span className="text-[10px] font-mono text-slate-400">ISO 10816-5</span>
              </h3>
              <span className="text-xs font-mono text-amber-400">
                Peak: {unit.vibrationSpectrum[2].amplitudeMmS} mm/s
              </span>
            </div>

            <p className="text-xs text-slate-400 mb-3 leading-relaxed">
              Triaxial accelerometer on turbine guide bearing. Peak at 108.3 Hz corresponds to 13-blade runner pass frequency.
            </p>

            {/* Vibration Bar Chart */}
            <div className="space-y-3 py-2">
              {unit.vibrationSpectrum.map((band, idx) => {
                const percent = (band.amplitudeMmS / band.limitMmS) * 100;
                const isWarning = band.amplitudeMmS > 3.0;
                return (
                  <div key={idx} className="space-y-1">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="text-slate-300">
                        {band.freqHz} Hz {idx === 0 ? '(1X Rotational)' : idx === 2 ? '(Blade Pass)' : ''}
                      </span>
                      <span className={isWarning ? 'text-amber-400 font-bold' : 'text-slate-300'}>
                        {band.amplitudeMmS} / {band.limitMmS} mm/s
                      </span>
                    </div>
                    <div className="w-full bg-slate-800 rounded h-2 overflow-hidden relative">
                      {/* Warning threshold line at 65% */}
                      <div className="absolute top-0 bottom-0 left-[66%] w-0.5 bg-amber-500/50 z-10" />
                      <div
                        className={`h-2 rounded transition-all duration-300 ${
                          isWarning ? 'bg-amber-400' : 'bg-emerald-400'
                        }`}
                        style={{ width: `${Math.min(100, percent)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 mt-3 flex items-center justify-between text-xs text-slate-400">
            <span>Acoustic Cavitation Noise:</span>
            <span className="font-mono font-bold text-white">{unit.acousticEmissionDb} dB</span>
          </div>
        </div>
      </div>

      {/* Bottom Grid: Bearing Thermal Matrix & Runner Blade Inspection Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Bearing RTD Temperature Telemetry (6 cols) */}
        <div className="lg:col-span-6 bg-[#0c1424] border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Thermometer className="w-4 h-4 text-sky-400" />
              <span>Duplex Pt100 RTD Thermal Sensor Telemetry</span>
            </h3>
            <span className="text-xs text-slate-400 font-mono">Continuous Polling</span>
          </div>

          <div className="space-y-3">
            {unit.temperatureSensors.map((t, idx) => (
              <div
                key={idx}
                className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-medium text-slate-200">{t.location}</div>
                  <div className="text-[11px] text-slate-500 font-mono">
                    Trip Limit: {t.thresholdC}°C
                  </div>
                </div>

                <div className="text-right">
                  <div
                    className={`font-mono text-base font-bold ${
                      t.status === 'warm'
                        ? 'text-amber-400'
                        : t.status === 'critical'
                        ? 'text-rose-400'
                        : 'text-emerald-400'
                    }`}
                  >
                    {t.valueC}°C
                  </div>
                  <div className="text-[10px] uppercase font-mono text-slate-400">
                    {t.status}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Runner Blade Material & Erosion Status (6 cols) */}
        <div className="lg:col-span-6 bg-[#0c1424] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Wrench className="w-4 h-4 text-amber-400" />
                <span>Runner Metallurgical & Erosion Inspection</span>
              </h3>
              <span className="text-xs font-mono text-slate-400">
                Overhaul in ~{Math.max(120, 8000 - unit.hoursSinceLastOverhaul)} hrs
              </span>
            </div>

            <div className="flex gap-4 items-center mb-4">
              <div className="w-24 h-24 rounded-lg overflow-hidden border border-slate-700 shrink-0">
                <img
                  src={IMAGES.turbineRunnerInspection}
                  alt="Turbine runner inspection"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="space-y-1 text-xs">
                <div className="font-bold text-white">{unit.runnerMaterial}</div>
                <div className="text-slate-400 text-[11px]">
                  Erosion Stage: <strong className="text-amber-400">{unit.erosionStage}</strong>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  {unit.unitId === 'unit-1'
                    ? 'HVOF ceramic coating demonstrates 4.5x greater abrasion resistance against 78% quartz sediment compared to uncoated stainless steel.'
                    : 'Uncoated 13Cr4Ni runner exhibits localized pitting along trailing blade edges, causing minor boundary layer turbulence.'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-3 border-t border-slate-800">
              <div className="p-2 rounded bg-slate-900 border border-slate-800">
                <div className="text-[10px] text-slate-500 uppercase">Cavitation Noise</div>
                <div className="text-white font-bold">{unit.acousticEmissionDb} dB</div>
              </div>
              <div className="p-2 rounded bg-slate-900 border border-slate-800">
                <div className="text-[10px] text-slate-500 uppercase">Service Hours</div>
                <div className="text-white font-bold">{unit.hoursSinceLastOverhaul} hrs</div>
              </div>
            </div>
          </div>

          <div className="mt-3 text-[11px] text-slate-500 flex items-center justify-between">
            <span>IEC 62364 Inspection Protocol compliant</span>
            <span className="text-sky-400 font-mono">Next Overhaul: Dec 2026</span>
          </div>
        </div>
      </div>
    </div>
  );
};
