import React, { useState } from 'react';
import { Plant } from '../../types/hydro';
import { evaluateMLPipelines } from '../../utils/physicsEngine';
import { MetricCard } from '../common/MetricCard';
import {
  Network,
  Cpu,
  Waves,
  Zap,
  Gauge,
  Sparkles,
  ArrowRight,
  Sliders,
  CheckCircle2,
  TrendingUp,
} from 'lucide-react';

interface MlArchitectureProps {
  currentPlant: Plant;
}

export const MlArchitecture: React.FC<MlArchitectureProps> = ({ currentPlant }) => {
  // Testbench Interactive Inputs matching the 15 features across the 3 models
  const [testRainfall, setTestRainfall] = useState<number>(14.5);
  const [testCumRainfall, setTestCumRainfall] = useState<number>(42.0);
  const [testRiverFlow, setTestRiverFlow] = useState<number>(currentPlant.currentFlowM3s);
  const [testWaterLevel, setTestWaterLevel] = useState<number>(1242.0);
  const [testPrevTurbidity, setTestPrevTurbidity] = useState<number>(currentPlant.currentTurbidityNTU);

  const [testVibration, setTestVibration] = useState<number>(2.4);
  const [testBearingTemp, setTestBearingTemp] = useState<number>(56.0);
  const [testRunnerHours, setTestRunnerHours] = useState<number>(3800);

  // Evaluate the 3-model pipeline live!
  const inference = evaluateMLPipelines({
    rainfallMm: testRainfall,
    cumulativeRainfallMm: testCumRainfall,
    riverFlowM3s: testRiverFlow,
    waterLevelM: testWaterLevel,
    previousTurbidityNTU: testPrevTurbidity,
    netHeadM: currentPlant.netHeadM,
    tailwaterM: 1.4,
    rpm: 500,
    vibrationMmS: testVibration,
    bearingTempC: testBearingTemp,
    sedimentNTU: testPrevTurbidity,
    runnerHours: testRunnerHours,
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="text-xs font-mono text-purple-400 flex items-center gap-1.5 mb-1">
            <Network className="w-3.5 h-3.5" />
            <span>SYSTEM ARCHITECTURE MODULE 11 · 3-MODEL ML PIPELINE</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Machine Learning Models in HydroIntelligence
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Three complementary machine learning models executing in cascade for sedimentation prediction, power generation forecasting, and turbine condition degradation.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="text-slate-500">Pipeline State:</span>
          <span className="text-emerald-400 font-semibold bg-emerald-950/60 px-2.5 py-1 rounded border border-emerald-800">
            HEALTHY (R² &gt; 0.94)
          </span>
        </div>
      </div>

      {/* Model Performance Top Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <MetricCard
          label="Model 1 Accuracy"
          value="0.942"
          unit="R²"
          subLabel="Model 1 RMSE"
          subValue="18.4 NTU"
          status="nominal"
          icon={<Waves className="w-3.5 h-3.5 text-amber-400" />}
        />
        <MetricCard
          label="Model 2 Accuracy"
          value="0.981"
          unit="R²"
          subLabel="Model 2 RMSE"
          subValue="0.12 MW"
          status="nominal"
          icon={<Zap className="w-3.5 h-3.5 text-sky-400" />}
        />
        <MetricCard
          label="Model 3 F1-Score"
          value="0.965"
          unit="F1"
          subLabel="Classification"
          subValue="97.2% Accuracy"
          status="nominal"
          icon={<Gauge className="w-3.5 h-3.5 text-purple-400" />}
        />
        <MetricCard
          label="Total Feature Slots"
          value="15"
          unit="Features"
          subLabel="Feature Pipeline"
          subValue="Shared Telemetry"
          status="nominal"
          icon={<Network className="w-3.5 h-3.5 text-slate-400" />}
        />
        <MetricCard
          label="Inference Latency"
          value="14.2"
          unit="ms"
          subLabel="Edge Deployment"
          subValue="ONNX Runtime"
          status="nominal"
          icon={<Cpu className="w-3.5 h-3.5 text-emerald-400" />}
        />
        <MetricCard
          label="Live Health Index"
          value={inference.model3.healthScore}
          unit="/100"
          subLabel="Current Grade"
          subValue={inference.model3.degradationClass.split(' ')[0]}
          status="nominal"
          icon={<Sparkles className="w-3.5 h-3.5 text-purple-400" />}
        />
      </div>

      {/* 3 Core Model Cards (Directly matching user's architecture diagram) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Model 1: Sedimentation Prediction */}
        <div className="bg-[#0c1424] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded bg-sky-950 flex items-center justify-center border border-sky-800">
                  <Waves className="w-3.5 h-3.5 text-sky-400" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                    Model 1: Sedimentation Prediction
                  </h3>
                  <div className="text-[10px] text-slate-400 font-mono">Future sediment/turbidity level</div>
                </div>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              Predicts future sediment/turbidity concentration in the reservoir/river based on environmental and hydrological conditions. Enables early warning for high sediment inflow.
            </p>

            <div className="space-y-1.5 text-xs font-mono mb-4">
              <div className="text-[10px] uppercase font-bold text-slate-500 font-mono">Input Features (5):</div>
              <div className="flex justify-between p-1.5 rounded bg-slate-900 border border-slate-800/80 text-[11px]">
                <span className="text-slate-300">1. Rainfall</span>
                <span className="text-slate-400">Current rain (mm)</span>
              </div>
              <div className="flex justify-between p-1.5 rounded bg-slate-900 border border-slate-800/80 text-[11px]">
                <span className="text-slate-300">2. Cumulative Rainfall</span>
                <span className="text-slate-400">Aggregated previous hrs</span>
              </div>
              <div className="flex justify-between p-1.5 rounded bg-slate-900 border border-slate-800/80 text-[11px]">
                <span className="text-slate-300">3. River Flow Rate</span>
                <span className="text-slate-400">Discharge / flow (m³/s)</span>
              </div>
              <div className="flex justify-between p-1.5 rounded bg-slate-900 border border-slate-800/80 text-[11px]">
                <span className="text-slate-300">4. Water Level</span>
                <span className="text-slate-400">River/reservoir level (m)</span>
              </div>
              <div className="flex justify-between p-1.5 rounded bg-slate-900 border border-slate-800/80 text-[11px]">
                <span className="text-slate-300">5. Previous Turbidity</span>
                <span className="text-slate-400">Recent NTU / mg/L</span>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 space-y-2 text-xs font-mono">
            <div className="flex justify-between">
              <span className="text-slate-500">Target Output:</span>
              <span className="text-amber-400 font-bold">Sediment Concentration (NTU)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Suggested Model:</span>
              <span className="text-white font-semibold">XGBoost Regressor</span>
            </div>
          </div>
        </div>

        {/* Model 2: Power Generation Prediction */}
        <div className="bg-[#0c1424] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded bg-emerald-950 flex items-center justify-center border border-emerald-800">
                  <Zap className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                    Model 2: Power Generation Prediction
                  </h3>
                  <div className="text-[10px] text-slate-400 font-mono">Future power output (MW/kW)</div>
                </div>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              Predicts expected electrical power generation of the hydropower plant based on hydraulic head, turbine operating state, and sediment level. Guides optimal dispatch.
            </p>

            <div className="space-y-1.5 text-xs font-mono mb-4">
              <div className="text-[10px] uppercase font-bold text-slate-500 font-mono">Input Features (5):</div>
              <div className="flex justify-between p-1.5 rounded bg-slate-900 border border-slate-800/80 text-[11px]">
                <span className="text-slate-300">1. River Flow Rate</span>
                <span className="text-slate-400">Discharge / flow (m³/s)</span>
              </div>
              <div className="flex justify-between p-1.5 rounded bg-slate-900 border border-slate-800/80 text-[11px]">
                <span className="text-slate-300">2. Hydraulic Head</span>
                <span className="text-slate-400">Effective net head (m)</span>
              </div>
              <div className="flex justify-between p-1.5 rounded bg-slate-900 border border-slate-800/80 text-[11px]">
                <span className="text-slate-300">3. Tailwater Level</span>
                <span className="text-slate-400">Upstream/downstream (m)</span>
              </div>
              <div className="flex justify-between p-1.5 rounded bg-slate-900 border border-slate-800/80 text-[11px]">
                <span className="text-slate-300">4. Turbine Operating (RPM)</span>
                <span className="text-slate-400">Rotational speed (RPM)</span>
              </div>
              <div className="flex justify-between p-1.5 rounded bg-slate-900 border border-slate-800/80 text-[11px]">
                <span className="text-slate-300">5. Sediment / Turbidity</span>
                <span className="text-slate-400">From Model 1 (NTU)</span>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 space-y-2 text-xs font-mono">
            <div className="flex justify-between">
              <span className="text-slate-500">Target Output:</span>
              <span className="text-sky-400 font-bold">Power Output (kW or MW)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Suggested Model:</span>
              <span className="text-white font-semibold">XGBoost Regressor</span>
            </div>
          </div>
        </div>

        {/* Model 3: Turbine Health Prediction */}
        <div className="bg-[#0c1424] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded bg-purple-950 flex items-center justify-center border border-purple-800">
                  <Gauge className="w-3.5 h-3.5 text-purple-400" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                    Model 3: Turbine Health Prediction
                  </h3>
                  <div className="text-[10px] text-slate-400 font-mono">Turbine health & degradation</div>
                </div>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              Predicts health condition and erosion degradation of the turbine based on operational vibration and thermal telemetry. Reduces maintenance costs and prevents sudden trips.
            </p>

            <div className="space-y-1.5 text-xs font-mono mb-4">
              <div className="text-[10px] uppercase font-bold text-slate-500 font-mono">Input Features (5):</div>
              <div className="flex justify-between p-1.5 rounded bg-slate-900 border border-slate-800/80 text-[11px]">
                <span className="text-slate-300">1. Vibration</span>
                <span className="text-slate-400">Vibration level (mm/s or g)</span>
              </div>
              <div className="flex justify-between p-1.5 rounded bg-slate-900 border border-slate-800/80 text-[11px]">
                <span className="text-slate-300">2. Turbine Temperature</span>
                <span className="text-slate-400">Bearing temp (°C)</span>
              </div>
              <div className="flex justify-between p-1.5 rounded bg-slate-900 border border-slate-800/80 text-[11px]">
                <span className="text-slate-300">3. Shaft RPM</span>
                <span className="text-slate-400">Rotational speed (RPM)</span>
              </div>
              <div className="flex justify-between p-1.5 rounded bg-slate-900 border border-slate-800/80 text-[11px]">
                <span className="text-slate-300">4. Power Output</span>
                <span className="text-slate-400">From Model 2 (MW)</span>
              </div>
              <div className="flex justify-between p-1.5 rounded bg-slate-900 border border-slate-800/80 text-[11px]">
                <span className="text-slate-300">5. Sediment Exposure</span>
                <span className="text-slate-400">Cumulative ppm-hours</span>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 space-y-2 text-xs font-mono">
            <div className="flex justify-between">
              <span className="text-slate-500">Target Output:</span>
              <span className="text-purple-400 font-bold">Turbine Health (0-100)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Suggested Model:</span>
              <span className="text-white font-semibold">Random Forest Classifier</span>
            </div>
          </div>
        </div>
      </div>

      {/* Live Interactive 3-Stage Pipeline Testbench */}
      <div className="bg-[#0c1424] border border-slate-800 rounded-xl p-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div>
            <h3 className="text-sm font-semibold text-white">Live Pipeline Inference Testbench</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Modify raw input features to watch real-time inference cascade through Model 1 → Model 2 → Model 3
            </p>
          </div>
          <span className="text-xs font-mono text-purple-400 font-bold">ACTIVE SIMULATOR</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Controls (6 cols) */}
          <div className="lg:col-span-6 space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Rainfall (mm): <strong className="text-white font-mono">{testRainfall}</strong></label>
                <input
                  type="range"
                  min="0"
                  max="50"
                  value={testRainfall}
                  onChange={(e) => setTestRainfall(Number(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded accent-sky-400"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Cumulative Rain (mm): <strong className="text-white font-mono">{testCumRainfall}</strong></label>
                <input
                  type="range"
                  min="0"
                  max="150"
                  value={testCumRainfall}
                  onChange={(e) => setTestCumRainfall(Number(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded accent-sky-400"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">River Flow (m³/s): <strong className="text-white font-mono">{testRiverFlow}</strong></label>
                <input
                  type="range"
                  min="3"
                  max="20"
                  step="0.2"
                  value={testRiverFlow}
                  onChange={(e) => setTestRiverFlow(Number(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded accent-blue-400"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Prior Turbidity (NTU): <strong className="text-white font-mono">{testPrevTurbidity}</strong></label>
                <input
                  type="range"
                  min="50"
                  max="2000"
                  step="25"
                  value={testPrevTurbidity}
                  onChange={(e) => setTestPrevTurbidity(Number(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded accent-amber-400"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Shaft Vibration (mm/s): <strong className="text-white font-mono">{testVibration}</strong></label>
                <input
                  type="range"
                  min="0.5"
                  max="6.0"
                  step="0.1"
                  value={testVibration}
                  onChange={(e) => setTestVibration(Number(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded accent-rose-400"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Bearing Temp (°C): <strong className="text-white font-mono">{testBearingTemp}</strong></label>
                <input
                  type="range"
                  min="40"
                  max="85"
                  step="1"
                  value={testBearingTemp}
                  onChange={(e) => setTestBearingTemp(Number(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded accent-amber-400"
                />
              </div>
            </div>
          </div>

          {/* Real-time Outputs Cascade (6 cols) */}
          <div className="lg:col-span-6 space-y-3 font-mono text-xs">
            {/* Step 1 */}
            <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-[10px] text-sky-400 font-bold">MODEL 1 PREDICTION (XGBOOST)</div>
                <div className="text-slate-300">Predicted River Sediment Concentration:</div>
              </div>
              <div className="text-base font-bold text-amber-400">
                {inference.model1.predictedSedimentNTU} NTU
              </div>
            </div>

            {/* Step 2 */}
            <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-[10px] text-emerald-400 font-bold">MODEL 2 PREDICTION (XGBOOST)</div>
                <div className="text-slate-300">Predicted Electrical Power Output:</div>
              </div>
              <div className="text-base font-bold text-sky-400">
                {inference.model2.predictedPowerMW} MW
              </div>
            </div>

            {/* Step 3 */}
            <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-[10px] text-purple-400 font-bold">MODEL 3 PREDICTION (RANDOM FOREST)</div>
                <div className="text-slate-300">Turbine Health Score & Condition:</div>
              </div>
              <div className="text-right">
                <div className="text-base font-bold text-purple-400">
                  {inference.model3.healthScore} / 100
                </div>
                <div className="text-[10px] text-slate-400">{inference.model3.degradationClass}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
