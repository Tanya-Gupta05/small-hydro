import React, { useState } from 'react';
import { Plant, PlantRevampOption } from '../../types/hydro';
import { PLANT_REVAMP_STUDY } from '../../data/mockHydroData';
import { MetricCard } from '../common/MetricCard';
import {
  Wrench,
  TrendingUp,
  DollarSign,
  ShieldCheck,
  CheckCircle2,
  Leaf,
  Layers,
  Sparkles,
} from 'lucide-react';

interface PlantRevampProps {
  currentPlant: Plant;
}

export const PlantRevamp: React.FC<PlantRevampProps> = ({ currentPlant }) => {
  const [selectedOptionId, setSelectedOptionId] = useState<string>('rv-1');
  const [customTariffINR, setCustomTariffINR] = useState<number>(4.25);

  const options = PLANT_REVAMP_STUDY;
  const activeOption = options.find((o) => o.id === selectedOptionId) || options[0];

  // Totals if all recommended RM&U options are executed
  const totalCapexLakh = options.reduce((acc, o) => acc + o.estimatedCapexLakhINR, 0);
  const totalGainMWh = options.reduce((acc, o) => acc + o.annualGenerationGainMWh, 0);
  const totalRevenueGainLakh = Number(((totalGainMWh * customTariffINR * 1000) / 100000).toFixed(2));
  const blendedPaybackYears = Number((totalCapexLakh / totalRevenueGainLakh).toFixed(2));
  const totalCO2Tons = options.reduce((acc, o) => acc + o.co2OffsetTonsPerYear, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="text-xs font-mono text-amber-400 flex items-center gap-1.5 mb-1">
            <Wrench className="w-3.5 h-3.5" />
            <span>SITE & DECISION INTELLIGENCE MODULE 08 · RM&U LIFE EXTENSION</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Existing Plant Revamp, Modernization (RM&U) & Life Extension
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Engineering feasibility, capital budgeting, and Levelized Cost of Energy (LCOE) optimization for runner coatings, digital governors, and desilting basin enlargements.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="text-slate-400">PPA Tariff:</span>
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 px-2 py-1 rounded">
            <span className="text-amber-400 font-bold">₹{customTariffINR.toFixed(2)}</span>
            <span className="text-slate-500">/kWh</span>
          </div>
        </div>
      </div>

      {/* Aggregate RM&U Portfolio Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <MetricCard
          label="Total Revamp CAPEX"
          value={`₹${(totalCapexLakh / 100).toFixed(2)} Cr`}
          unit=""
          subLabel="4 Package Scope"
          subValue={`₹${totalCapexLakh} Lakh`}
          status="nominal"
          icon={<DollarSign className="w-3.5 h-3.5 text-amber-400" />}
        />
        <MetricCard
          label="Annual Energy Gain"
          value={totalGainMWh.toLocaleString()}
          unit="MWh/yr"
          subLabel="Generation Uplift"
          subValue="+7.2% Yield"
          status="nominal"
          icon={<TrendingUp className="w-3.5 h-3.5 text-emerald-400" />}
          trend={{ direction: 'up', value: '+5.03 GWh' }}
        />
        <MetricCard
          label="Annual Revenue Uplift"
          value={`₹${totalRevenueGainLakh}`}
          unit="Lakh/yr"
          subLabel="At Current PPA"
          subValue={`₹${(totalRevenueGainLakh / 100).toFixed(2)} Cr/yr`}
          status="nominal"
          icon={<Sparkles className="w-3.5 h-3.5 text-sky-400" />}
        />
        <MetricCard
          label="Blended Payback"
          value={blendedPaybackYears}
          unit="Years"
          subLabel="IRR Return"
          subValue="42.6% Internal Rate"
          status="nominal"
          icon={<CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
          trend={{ direction: 'up', value: '< 14 Months' }}
        />
        <MetricCard
          label="Runner Life Extension"
          value="+4.5x"
          unit="Longevity"
          subLabel="HVOF Ceramic"
          subValue="18,000+ Hours"
          status="nominal"
          icon={<ShieldCheck className="w-3.5 h-3.5 text-purple-400" />}
        />
        <MetricCard
          label="Decarbonization Offset"
          value={totalCO2Tons.toLocaleString()}
          unit="T CO₂/yr"
          subLabel="Clean Energy"
          subValue="CEA Grid Factor"
          status="nominal"
          icon={<Leaf className="w-3.5 h-3.5 text-emerald-400" />}
        />
      </div>

      {/* Main Dual Grid: Package Selector on Left & Deep Financial Breakdown on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: 4 Revamp Packages (5 cols) */}
        <div className="lg:col-span-5 bg-[#0c1424] border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <h3 className="text-sm font-semibold text-white">RM&U Intervention Packages</h3>
            <span className="text-xs text-slate-500 font-mono">Ranked by Payback</span>
          </div>

          <div className="space-y-2.5">
            {options.map((opt) => {
              const isSelected = opt.id === selectedOptionId;
              return (
                <button
                  key={opt.id}
                  onClick={() => setSelectedOptionId(opt.id)}
                  className={`w-full text-left p-3.5 rounded-lg border transition-all ${
                    isSelected
                      ? 'bg-amber-950/20 border-amber-700/80 shadow-xs'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700 hover:bg-slate-850'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <span className="text-xs font-bold text-white leading-snug">
                      {opt.title}
                    </span>
                    <span className="text-[10px] font-mono text-emerald-400 font-bold shrink-0">
                      {opt.paybackPeriodYears} yr ROI
                    </span>
                  </div>

                  <div className="text-[11px] text-slate-400 mb-2 line-clamp-2">
                    {opt.description}
                  </div>

                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-slate-400">
                    <span>CAPEX: <strong className="text-white">₹{opt.estimatedCapexLakhINR} Lakh</strong></span>
                    <span>Gain: <strong className="text-emerald-400">+{opt.annualGenerationGainMWh} MWh</strong></span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Selected Package Deep Dive & Implementation Scope (7 cols) */}
        <div className="lg:col-span-7 bg-[#0c1424] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <div>
                <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-wider">
                  [{activeOption.category.toUpperCase()}]
                </span>
                <h3 className="text-base font-bold text-white mt-0.5">
                  {activeOption.title}
                </h3>
              </div>
              <span className="px-2.5 py-1 rounded text-xs font-mono bg-emerald-950 text-emerald-300 border border-emerald-800">
                {activeOption.status}
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              {activeOption.description}
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4">
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono">
                <div className="text-[10px] text-slate-500 uppercase">Estimated CAPEX</div>
                <div className="text-white font-bold text-base mt-0.5">₹{activeOption.estimatedCapexLakhINR} Lakh</div>
              </div>
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono">
                <div className="text-[10px] text-slate-500 uppercase">Annual MWh Gain</div>
                <div className="text-emerald-400 font-bold text-base mt-0.5">+{activeOption.annualGenerationGainMWh} MWh</div>
              </div>
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono">
                <div className="text-[10px] text-slate-500 uppercase">Annual Revenue</div>
                <div className="text-sky-400 font-bold text-base mt-0.5">₹{activeOption.annualRevenueGainLakhINR} Lakh</div>
              </div>
            </div>

            <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono mb-2">
              Implementation Timeline & Outage Window
            </h4>

            <div className="space-y-2 text-xs font-mono">
              <div className="flex justify-between items-center p-2 rounded bg-slate-900/60 border border-slate-800 text-slate-300">
                <span>Phase 1: Petrographic & Runner Ultrasonic Profiling</span>
                <span className="text-slate-400">14 Days (Running)</span>
              </div>
              <div className="flex justify-between items-center p-2 rounded bg-slate-900/60 border border-slate-800 text-slate-300">
                <span>Phase 2: Lean Season Planned Unit Isolation Window</span>
                <span className="text-amber-400 font-semibold">12 Days Outage</span>
              </div>
              <div className="flex justify-between items-center p-2 rounded bg-slate-900/60 border border-slate-800 text-slate-300">
                <span>Phase 3: Acceptance Testing & Grid Synchronization</span>
                <span className="text-emerald-400">3 Days</span>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 mt-4 flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>Ministry of New and Renewable Energy (MNRE) Subsidy Eligible</span>
            <span className="text-emerald-400 font-bold">FEASIBILITY APPROVED</span>
          </div>
        </div>
      </div>
    </div>
  );
};
