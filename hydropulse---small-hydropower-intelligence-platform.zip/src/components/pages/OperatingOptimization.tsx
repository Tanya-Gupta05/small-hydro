import React, { useState } from 'react';
import { Plant } from '../../types/hydro';
import { OPERATING_DISPATCH_DATA } from '../../data/mockHydroData';
import { MetricCard } from '../common/MetricCard';
import {
  Sliders,
  Zap,
  TrendingUp,
  ArrowRight,
  CheckCircle2,
  Activity,
  Layers,
  Sparkles,
  Info,
} from 'lucide-react';

interface OperatingOptimizationProps {
  currentPlant: Plant;
}

export const OperatingOptimization: React.FC<OperatingOptimizationProps> = ({ currentPlant }) => {
  const [isOptimized, setIsOptimized] = useState<boolean>(false);
  const [unit1GVO, setUnit1GVO] = useState<number>(88);
  const [unit2GVO, setUnit2GVO] = useState<number>(91);
  const [dispatchMessage, setDispatchMessage] = useState<string | null>(null);

  const baseData = OPERATING_DISPATCH_DATA;

  const handleApplyOptimization = () => {
    setIsOptimized(true);
    setUnit1GVO(84);
    setUnit2GVO(74);
    setDispatchMessage('Optimal dispatch setpoints applied via Governor PLC');
    setTimeout(() => setDispatchMessage(null), 4000);
  };

  const handleReset = () => {
    setIsOptimized(false);
    setUnit1GVO(88);
    setUnit2GVO(91);
    setDispatchMessage('Reverted to manual operator setpoint');
    setTimeout(() => setDispatchMessage(null), 3000);
  };

  // Dynamic calculations based on user GVO sliders
  const flowUnit1 = Number(((currentPlant.currentFlowM3s * unit1GVO) / (unit1GVO + unit2GVO)).toFixed(2));
  const flowUnit2 = Number((currentPlant.currentFlowM3s - flowUnit1).toFixed(2));

  // Efficiencies
  const effUnit1 = Number((93.2 - Math.pow((unit1GVO - 84) * 0.25, 2)).toFixed(1));
  const effUnit2 = Number((89.5 - Math.pow((unit2GVO - 76) * 0.35, 2)).toFixed(1));

  const mwUnit1 = Number(((9.81 * flowUnit1 * currentPlant.currentHeadM * (effUnit1 / 100)) / 1000).toFixed(2));
  const mwUnit2 = Number(((9.81 * flowUnit2 * currentPlant.currentHeadM * (effUnit2 / 100)) / 1000).toFixed(2));
  const totalSimulatedMW = Number((mwUnit1 + mwUnit2).toFixed(2));
  const deltaMW = Number((totalSimulatedMW - currentPlant.currentPowerMW).toFixed(2));
  const dailyGainINR = Math.round(deltaMW * 24 * 4250);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="text-xs font-mono text-emerald-400 flex items-center gap-1.5 mb-1">
            <Sliders className="w-3.5 h-3.5" />
            <span>CORE INTELLIGENCE MODULE 03 · DYNAMIC DISPATCH OPTIMIZER</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Dynamic Hydro Operating Optimization & Multi-Unit Commitment
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Non-linear constraint optimization aligning runner Hill curve sweet spots with Time-of-Day (ToD) tariff schedules and quartz erosion minimization.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {isOptimized ? (
            <button
              onClick={handleReset}
              className="px-3 py-2 rounded text-xs font-mono text-slate-300 bg-slate-900 border border-slate-700 hover:bg-slate-800 transition-colors"
            >
              Reset to Manual
            </button>
          ) : (
            <button
              onClick={handleApplyOptimization}
              className="px-4 py-2 rounded text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Apply Recommended Setpoint</span>
            </button>
          )}
        </div>
      </div>

      {dispatchMessage && (
        <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-800/80 text-xs text-emerald-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{dispatchMessage}</span>
          </div>
          <span className="font-mono text-[10px] text-emerald-400">PLC ACKNOWLEDGED</span>
        </div>
      )}

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <MetricCard
          label="Total Plant Dispatch"
          value={totalSimulatedMW}
          unit="MW"
          subLabel="Baseline"
          subValue={`${currentPlant.currentPowerMW} MW`}
          status={deltaMW >= 0 ? 'nominal' : 'warning'}
          icon={<Zap className="w-3.5 h-3.5 text-sky-400" />}
          trend={{ direction: deltaMW >= 0 ? 'up' : 'down', value: `${deltaMW >= 0 ? '+' : ''}${deltaMW} MW` }}
        />
        <MetricCard
          label="Daily Revenue Delta"
          value={dailyGainINR >= 0 ? `+₹${dailyGainINR.toLocaleString()}` : `-₹${Math.abs(dailyGainINR).toLocaleString()}`}
          unit=""
          subLabel="At INR 4.25/kWh"
          subValue="Base Tariff"
          status={dailyGainINR >= 0 ? 'nominal' : 'warning'}
          icon={<TrendingUp className="w-3.5 h-3.5 text-emerald-400" />}
        />
        <MetricCard
          label="Unit 1 Optimal GVO"
          value={unit1GVO}
          unit="%"
          subLabel="Target Setpoint"
          subValue="84.0% Optimal"
          status={unit1GVO === 84 ? 'nominal' : 'advisory'}
          icon={<Sliders className="w-3.5 h-3.5 text-purple-400" />}
        />
        <MetricCard
          label="Unit 2 Optimal GVO"
          value={unit2GVO}
          unit="%"
          subLabel="Erosion Limit"
          subValue="74.0% Optimal"
          status={unit2GVO === 74 ? 'nominal' : 'advisory'}
          icon={<Sliders className="w-3.5 h-3.5 text-amber-400" />}
        />
        <MetricCard
          label="Head Loss Reduction"
          value="0.32"
          unit="m"
          subLabel="Net Penstock Head"
          subValue={`${(currentPlant.currentHeadM + 0.32).toFixed(1)} m`}
          status="nominal"
          icon={<Activity className="w-3.5 h-3.5 text-blue-400" />}
        />
        <MetricCard
          label="Optimization Status"
          value={isOptimized ? 'OPTIMAL' : 'MANUAL'}
          unit=""
          subLabel="Solver"
          subValue="SQP Non-Linear"
          status={isOptimized ? 'nominal' : 'warning'}
          icon={<Sparkles className="w-3.5 h-3.5 text-emerald-400" />}
        />
      </div>

      {/* Main Dual Grid: Comparison & Live Sliders */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Current vs Recommended Comparison Card (7 cols) */}
        <div className="lg:col-span-7 bg-[#0c1424] border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Current vs Recommended Operating Point</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Balancing load towards HVOF-coated Unit 1 to maximize hydraulic efficiency while curtailing vortex turbulence on Unit 2
              </p>
            </div>
            <span className="text-xs font-mono text-emerald-400 font-bold">+3.4% Plant Gain</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                  <th className="py-2.5 px-3">Operating Parameter</th>
                  <th className="py-2.5 px-3 text-slate-400">Current Manual</th>
                  <th className="py-2.5 px-3 text-emerald-400 font-bold">Recommended ML</th>
                  <th className="py-2.5 px-3 text-sky-400">Net Delta</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                <tr>
                  <td className="py-2.5 px-3 font-sans font-medium text-slate-200">Total Plant Generation</td>
                  <td className="py-2.5 px-3 text-slate-400">10.42 MW</td>
                  <td className="py-2.5 px-3 text-emerald-400 font-bold">10.78 MW</td>
                  <td className="py-2.5 px-3 text-emerald-400">+0.36 MW</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3 font-sans font-medium text-slate-200">Unit 1 Flow Allocation</td>
                  <td className="py-2.5 px-3 text-slate-400">5.60 m³/s (50%)</td>
                  <td className="py-2.5 px-3 text-emerald-400 font-bold">6.20 m³/s (55.4%)</td>
                  <td className="py-2.5 px-3 text-sky-400">+0.60 m³/s</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3 font-sans font-medium text-slate-200">Unit 2 Flow Allocation</td>
                  <td className="py-2.5 px-3 text-slate-400">5.60 m³/s (50%)</td>
                  <td className="py-2.5 px-3 text-emerald-400 font-bold">5.00 m³/s (44.6%)</td>
                  <td className="py-2.5 px-3 text-amber-400">-0.60 m³/s</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3 font-sans font-medium text-slate-200">Unit 1 Guide Vane Opening</td>
                  <td className="py-2.5 px-3 text-slate-400">88.0%</td>
                  <td className="py-2.5 px-3 text-emerald-400 font-bold">84.0% (Sweet spot)</td>
                  <td className="py-2.5 px-3 text-slate-300">-4.0% (Trim)</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3 font-sans font-medium text-slate-200">Unit 2 Guide Vane Opening</td>
                  <td className="py-2.5 px-3 text-slate-400">91.0%</td>
                  <td className="py-2.5 px-3 text-emerald-400 font-bold">74.0% (Safe anti-vortex)</td>
                  <td className="py-2.5 px-3 text-amber-400">-17.0%</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3 font-sans font-medium text-slate-200">Abrasive Wear Suppression</td>
                  <td className="py-2.5 px-3 text-slate-400">0.31 mm/1k h</td>
                  <td className="py-2.5 px-3 text-emerald-400 font-bold">0.19 mm/1k h</td>
                  <td className="py-2.5 px-3 text-emerald-400">-38.7% Erosion</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Right: Live Interactive Operator Setpoint Tuning Sliders (5 cols) */}
        <div className="lg:col-span-5 bg-[#0c1424] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <h3 className="text-sm font-semibold text-white">Manual Operator GVO Tuning</h3>
              <Info className="w-3.5 h-3.5 text-slate-500" />
            </div>

            <p className="text-xs text-slate-400 mb-4 leading-relaxed">
              Adjust individual unit guide vane opening angles to observe real-time hydraulic flow division and electrical generation impact.
            </p>

            <div className="space-y-4">
              {/* Unit 1 Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-slate-200">Unit 1 GVO Aperture</span>
                  <span className="font-mono text-sky-400 font-bold">{unit1GVO}%</span>
                </div>
                <input
                  type="range"
                  min="40"
                  max="100"
                  step="1"
                  value={unit1GVO}
                  onChange={(e) => {
                    setUnit1GVO(Number(e.target.value));
                    setIsOptimized(false);
                  }}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>40% (Min Stable)</span>
                  <span>84% (Optimum)</span>
                  <span>100% (Max)</span>
                </div>
              </div>

              {/* Unit 2 Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-slate-200">Unit 2 GVO Aperture</span>
                  <span className="font-mono text-amber-400 font-bold">{unit2GVO}%</span>
                </div>
                <input
                  type="range"
                  min="40"
                  max="100"
                  step="1"
                  value={unit2GVO}
                  onChange={(e) => {
                    setUnit2GVO(Number(e.target.value));
                    setIsOptimized(false);
                  }}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>40% (Min Stable)</span>
                  <span>74% (Optimum)</span>
                  <span>100% (Max)</span>
                </div>
              </div>
            </div>

            {/* Calculated Breakdown Box */}
            <div className="mt-5 p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-2 text-xs font-mono">
              <div className="flex justify-between text-slate-300">
                <span>Unit 1 Flow / Output:</span>
                <span className="text-white font-bold">{flowUnit1} m³/s · {mwUnit1} MW</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Unit 2 Flow / Output:</span>
                <span className="text-white font-bold">{flowUnit2} m³/s · {mwUnit2} MW</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-slate-800 text-slate-300">
                <span>Calculated Total:</span>
                <span className="text-emerald-400 font-bold">{totalSimulatedMW} MW</span>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 mt-4 flex items-center justify-between text-xs">
            <span className="text-slate-500">Live governor feedback loop</span>
            <button
              onClick={handleApplyOptimization}
              className="text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1"
            >
              <span>Auto-Calibrate</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
