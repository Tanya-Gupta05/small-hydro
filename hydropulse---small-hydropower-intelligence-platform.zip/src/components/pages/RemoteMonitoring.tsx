import React, { useState, useEffect } from 'react';
import { Plant } from '../../types/hydro';
import { MetricCard } from '../common/MetricCard';
import {
  Radio,
  Activity,
  Zap,
  Gauge,
  Thermometer,
  Waves,
  AlertTriangle,
  CheckCircle2,
  Lock,
  RefreshCw,
  Sliders,
} from 'lucide-react';

interface RemoteMonitoringProps {
  currentPlant: Plant;
  isStreaming: boolean;
  onToggleStreaming: () => void;
}

interface SensorNode {
  id: string;
  name: string;
  category: 'hydraulic' | 'mechanical' | 'thermal' | 'electrical';
  location: string;
  value: string;
  unit: string;
  status: 'nominal' | 'warning' | 'critical';
  threshold: string;
  x: number;
  y: number;
}

export const RemoteMonitoring: React.FC<RemoteMonitoringProps> = ({
  currentPlant,
  isStreaming,
  onToggleStreaming,
}) => {
  const [selectedSensorId, setSelectedSensorId] = useState<string>('sns-runner-vib');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [tick, setTick] = useState<number>(0);

  // Subtle live vibration and power fluctuation when streaming is on
  useEffect(() => {
    if (!isStreaming) return;
    const interval = setInterval(() => {
      setTick((t) => t + 1);
    }, 1500);
    return () => clearInterval(interval);
  }, [isStreaming]);

  const jitterVibe = (isStreaming ? (Math.sin(tick) * 0.08).toFixed(2) : '0.00');
  const jitterMW = (isStreaming ? (Math.cos(tick * 0.7) * 0.04).toFixed(3) : '0.000');

  const sensors: SensorNode[] = [
    {
      id: 'sns-penstock-press',
      name: 'Penstock Inlet Piezoresistive Transmitter',
      category: 'hydraulic',
      location: 'Penstock Base / BFV',
      value: (11.6 + Number(jitterMW) * 0.5).toFixed(2),
      unit: 'bar',
      status: 'nominal',
      threshold: '14.0 bar max',
      x: 100,
      y: 220,
    },
    {
      id: 'sns-flowmeter',
      name: 'Ultrasonic Transit-Time Flow Sensor',
      category: 'hydraulic',
      location: 'Spiral Casing Inlet',
      value: (currentPlant.currentFlowM3s + Number(jitterMW) * 2).toFixed(2),
      unit: 'm³/s',
      status: 'nominal',
      threshold: '12.4 m³/s design',
      x: 200,
      y: 220,
    },
    {
      id: 'sns-gvo-pos',
      name: 'Guide Vane Servomotor LVDT Positioner',
      category: 'mechanical',
      location: 'Wicket Gate Ring',
      value: '84.2',
      unit: '% GVO',
      status: 'nominal',
      threshold: '100% max',
      x: 320,
      y: 190,
    },
    {
      id: 'sns-runner-vib',
      name: 'Runner Headcover Triaxial Accelerometer',
      category: 'mechanical',
      location: 'Turbine Headcover',
      value: (1.95 + Number(jitterVibe)).toFixed(2),
      unit: 'mm/s',
      status: Number(jitterVibe) > 0.05 ? 'warning' : 'nominal',
      threshold: '4.5 mm/s (ISO 10816)',
      x: 420,
      y: 230,
    },
    {
      id: 'sns-guide-bearing-temp',
      name: 'Turbine Guide Bearing Pt100 RTD',
      category: 'thermal',
      location: 'Lower Guide Bearing Housing',
      value: '52.8',
      unit: '°C',
      status: 'nominal',
      threshold: '65.0°C warning',
      x: 420,
      y: 160,
    },
    {
      id: 'sns-thrust-temp',
      name: 'Thrust Bearing Pad Thermocouple',
      category: 'thermal',
      location: 'Main Thrust Collar',
      value: '58.4',
      unit: '°C',
      status: 'nominal',
      threshold: '70.0°C warning',
      x: 420,
      y: 110,
    },
    {
      id: 'sns-gen-rpm',
      name: 'Shaft Magnetic Pickup Speed Encoder',
      category: 'electrical',
      location: 'Rotor Shaft Flywheel',
      value: (500.1 + (Number(jitterVibe) * 0.4)).toFixed(1),
      unit: 'RPM',
      status: 'nominal',
      threshold: '500.0 ±1%',
      x: 520,
      y: 80,
    },
    {
      id: 'sns-power-mw',
      name: 'Generator Digital Power Transducer',
      category: 'electrical',
      location: '33 kV Switchyard Feeder',
      value: (currentPlant.currentPowerMW + Number(jitterMW)).toFixed(3),
      unit: 'MW',
      status: 'nominal',
      threshold: '12.0 MW rated',
      x: 640,
      y: 70,
    },
    {
      id: 'sns-draft-tube',
      name: 'Draft Tube Dynamic Pressure Transducer',
      category: 'hydraulic',
      location: 'Elbow Draft Tube Cone',
      value: '0.28',
      unit: 'bar',
      status: 'nominal',
      threshold: '0.80 bar pulse',
      x: 420,
      y: 330,
    },
  ];

  const filteredSensors =
    categoryFilter === 'all'
      ? sensors
      : sensors.filter((s) => s.category === categoryFilter);

  const activeSensor =
    sensors.find((s) => s.id === selectedSensorId) || sensors[3];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="text-xs font-mono text-sky-400 flex items-center gap-1.5 mb-1">
            <Radio className="w-3.5 h-3.5" />
            <span>OPERATIONAL COCKPIT MODULE 10 · REAL-TIME SCADA TELEMETRY</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Remote Monitoring, SCADA Cross-Section & Sensor Telemetry
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Live sub-second telemetry feeds from the high-pressure penstock, spiral casing, Francis turbine runner, generator bearings, and elbow draft tube.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={onToggleStreaming}
            className={`px-3 py-1.5 rounded text-xs font-mono font-medium flex items-center gap-1.5 border transition-colors ${
              isStreaming
                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                isStreaming ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'
              }`}
            />
            <span>{isStreaming ? 'STREAMING (1.5s)' : 'TELEMETRY PAUSED'}</span>
          </button>
        </div>
      </div>

      {/* Primary Key Live Telemetry Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <MetricCard
          label="Active Power Flow"
          value={(currentPlant.currentPowerMW + Number(jitterMW)).toFixed(2)}
          unit="MW"
          subLabel="33 kV Grid"
          subValue="50.02 Hz Synced"
          status="nominal"
          icon={<Zap className="w-3.5 h-3.5 text-sky-400" />}
        />
        <MetricCard
          label="Penstock Flow"
          value={(currentPlant.currentFlowM3s + Number(jitterMW) * 2).toFixed(2)}
          unit="m³/s"
          subLabel="Inlet Velocity"
          subValue="2.85 m/s"
          status="nominal"
          icon={<Waves className="w-3.5 h-3.5 text-blue-400" />}
        />
        <MetricCard
          label="Turbine Shaft Speed"
          value={(500.1 + (Number(jitterVibe) * 0.4)).toFixed(1)}
          unit="RPM"
          subLabel="Deviation"
          subValue="±0.02%"
          status="nominal"
          icon={<Gauge className="w-3.5 h-3.5 text-purple-400" />}
        />
        <MetricCard
          label="Guide Bearing Vibration"
          value={(1.95 + Number(jitterVibe)).toFixed(2)}
          unit="mm/s"
          subLabel="Zone Status"
          subValue="Zone A (Nominal)"
          status={Number(jitterVibe) > 0.05 ? 'warning' : 'nominal'}
          icon={<Activity className="w-3.5 h-3.5 text-amber-400" />}
        />
        <MetricCard
          label="Thrust Bearing Temp"
          value="58.4"
          unit="°C"
          subLabel="Lube Oil In"
          subValue="41.2°C"
          status="nominal"
          icon={<Thermometer className="w-3.5 h-3.5 text-emerald-400" />}
        />
        <MetricCard
          label="Draft Tube Pressure"
          value="0.28"
          unit="bar"
          subLabel="Vortex Pulse"
          subValue="Minimal"
          status="nominal"
          icon={<CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
        />
      </div>

      {/* Main Schematic & Sensor Hotspots */}
      <div className="bg-[#0a0f1d] border border-slate-800 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold text-white">Powerhouse Mechanical & Electrical Cross-Section</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Click any circular node to inspect real-time sensor transducer specifications and trip tolerances
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-slate-500">Filter Sensors:</span>
            {['all', 'hydraulic', 'mechanical', 'thermal', 'electrical'].map((cat) => (
              <button
                key={cat}
                onClick={() => setCategoryFilter(cat)}
                className={`px-2 py-0.5 rounded uppercase text-[10px] transition-colors ${
                  categoryFilter === cat
                    ? 'bg-sky-950 text-sky-300 border border-sky-800'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* SVG Mechanical Schematic Canvas */}
        <div className="w-full h-[380px] relative select-none bg-[#070b14] bg-grid-pattern overflow-hidden">
          <svg viewBox="0 0 850 400" className="w-full h-full object-contain">
            {/* Penstock Conduit (Left to Center) */}
            <path
              d="M 20 220 L 220 220"
              stroke="#334155"
              strokeWidth="38"
              strokeLinecap="round"
            />
            <path
              d="M 20 220 L 220 220"
              stroke="#0284c7"
              strokeWidth="28"
              strokeLinecap="round"
              opacity="0.4"
            />

            {/* Spiral Casing (Volute) */}
            <ellipse
              cx="420"
              cy="230"
              rx="120"
              ry="75"
              fill="#0f172a"
              stroke="#334155"
              strokeWidth="4"
            />

            {/* Vertical Main Shaft */}
            <rect x="412" y="50" width="16" height="230" fill="#64748b" stroke="#334155" />

            {/* Generator Stator & Rotor (Top) */}
            <rect x="340" y="50" width="160" height="70" rx="6" fill="#1e293b" stroke="#38bdf8" strokeWidth="2" />
            <text x="420" y="88" fill="#e2e8f0" fontSize="12" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
              SYNCHRONOUS GENERATOR
            </text>

            {/* Francis Turbine Runner (Center) */}
            <path
              d="M 380 215 L 460 215 L 445 250 L 395 250 Z"
              fill="#475569"
              stroke="#cbd5e1"
              strokeWidth="2"
            />
            <text x="420" y="238" fill="#f8fafc" fontSize="10" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
              RUNNER
            </text>

            {/* Elbow Draft Tube (Bottom) */}
            <path
              d="M 390 250 L 370 360 L 520 360 L 450 250 Z"
              fill="#0f172a"
              stroke="#334155"
              strokeWidth="3"
            />
            <text x="440" y="320" fill="#64748b" fontSize="10" fontFamily="monospace">
              DRAFT TUBE
            </text>

            {/* Interactive Sensor Pins */}
            {filteredSensors.map((s) => {
              const isSelected = s.id === selectedSensorId;
              const color =
                s.category === 'hydraulic'
                  ? '#38bdf8'
                  : s.category === 'mechanical'
                  ? '#a855f7'
                  : s.category === 'thermal'
                  ? '#f59e0b'
                  : '#10b981';

              return (
                <g
                  key={s.id}
                  onClick={() => setSelectedSensorId(s.id)}
                  className="cursor-pointer transition-transform hover:scale-110"
                >
                  {isSelected && (
                    <circle
                      cx={s.x}
                      cy={s.y}
                      r={14}
                      fill="none"
                      stroke={color}
                      strokeWidth="1.5"
                      strokeDasharray="3 2"
                      className="animate-spin-slow"
                    />
                  )}
                  <circle
                    cx={s.x}
                    cy={s.y}
                    r={6.5}
                    fill={color}
                    stroke="#ffffff"
                    strokeWidth="1.8"
                  />
                  <text
                    x={s.x + 9}
                    y={s.y + 3}
                    fill={isSelected ? '#ffffff' : '#94a3b8'}
                    fontSize="9.5"
                    fontFamily="monospace"
                    fontWeight={isSelected ? 'bold' : 'normal'}
                  >
                    {s.value} {s.unit}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Selected Sensor Information Bar */}
        <div className="p-4 bg-[#080d1a] border-t border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold uppercase text-sky-400 bg-sky-950/60 px-2 py-0.5 rounded border border-sky-800/80">
                {activeSensor.category} SENSOR
              </span>
              <span className="text-xs text-slate-500">·</span>
              <span className="text-xs text-white font-semibold">{activeSensor.name}</span>
            </div>
            <div className="text-xs text-slate-400 font-mono">
              Mounted at: <strong className="text-slate-300">{activeSensor.location}</strong> · Safe Limit:{' '}
              <strong className="text-amber-400">{activeSensor.threshold}</strong>
            </div>
          </div>

          <div className="flex items-center gap-5 font-mono text-xs shrink-0">
            <div>
              <div className="text-[10px] text-slate-500 uppercase">Live Transducer Value</div>
              <div className="text-base font-bold text-sky-400">
                {activeSensor.value} {activeSensor.unit}
              </div>
            </div>
            <div className="px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-emerald-400 font-semibold text-[11px]">
              CALIBRATED
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
