import React, { useState } from 'react';
import {
  PRD_CONTENT,
  USER_ROLES_DATA,
  SUPABASE_SCHEMA_SQL,
  API_ENDPOINTS_SPEC,
  IOT_HARDWARE_BOM,
} from '../../data/technicalDocsData';
import {
  FileCode2,
  Users,
  Database,
  Globe,
  HardDrive,
  Copy,
  Check,
  Cpu,
  Layers,
  Sparkles,
} from 'lucide-react';

export const TechnicalSpecs: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'prd' | 'roles' | 'schema' | 'api' | 'stack'>('prd');
  const [copied, setCopied] = useState<boolean>(false);

  const handleCopySchema = () => {
    navigator.clipboard.writeText(SUPABASE_SCHEMA_SQL);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="text-xs font-mono text-slate-400 flex items-center gap-1.5 mb-1">
            <FileCode2 className="w-3.5 h-3.5 text-purple-400" />
            <span>TECHNICAL SPECIFICATIONS & SIH 2026 ARCHITECTURE DOSSIER</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Technical Architecture, PRD, Supabase Schema & API Contracts
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Complete technical deliverables for Smart India Hackathon: functional requirements, role-based access control, relational database schema with RLS, and IoT edge hardware topology.
          </p>
        </div>

        {/* Sub-tabs Navigation */}
        <div className="flex flex-wrap items-center gap-1 bg-slate-900 border border-slate-800 p-1 rounded-lg text-xs font-medium">
          <button
            onClick={() => setActiveSubTab('prd')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeSubTab === 'prd'
                ? 'bg-slate-800 text-white font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            PRD Document
          </button>
          <button
            onClick={() => setActiveSubTab('roles')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeSubTab === 'roles'
                ? 'bg-slate-800 text-white font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            User Roles
          </button>
          <button
            onClick={() => setActiveSubTab('schema')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeSubTab === 'schema'
                ? 'bg-slate-800 text-white font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Supabase Schema
          </button>
          <button
            onClick={() => setActiveSubTab('api')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeSubTab === 'api'
                ? 'bg-slate-800 text-white font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            API Endpoints
          </button>
          <button
            onClick={() => setActiveSubTab('stack')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeSubTab === 'stack'
                ? 'bg-slate-800 text-white font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Tech Stack & BOM
          </button>
        </div>
      </div>

      {/* Sub-tab 1: PRD */}
      {activeSubTab === 'prd' && (
        <div className="space-y-6">
          <div className="bg-[#0c1424] border border-slate-800 rounded-xl p-6 space-y-5">
            <div className="border-b border-slate-800 pb-4">
              <span className="text-[10px] font-mono uppercase text-sky-400 bg-sky-950 px-2 py-0.5 rounded border border-sky-800">
                {PRD_CONTENT.sihTrack}
              </span>
              <h2 className="text-lg font-bold text-white mt-2">{PRD_CONTENT.title}</h2>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                {PRD_CONTENT.executiveSummary}
              </p>
            </div>

            <div>
              <h3 className="text-xs font-bold text-white uppercase font-mono tracking-wider mb-2">
                1. Core Engineering Objectives
              </h3>
              <ul className="space-y-2 text-xs text-slate-300 list-disc pl-5">
                {PRD_CONTENT.objectives.map((obj, i) => (
                  <li key={i} className="leading-relaxed">{obj}</li>
                ))}
              </ul>
            </div>

            <div className="pt-2">
              <h3 className="text-xs font-bold text-white uppercase font-mono tracking-wider mb-3">
                2. Functional Module Requirements
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                {PRD_CONTENT.functionalRequirements.map((req, i) => (
                  <div key={i} className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
                    <div className="font-semibold text-sky-400 font-mono text-[11px]">{req.module}</div>
                    <div className="text-slate-300 leading-relaxed text-[11px]">{req.req}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sub-tab 2: User Roles */}
      {activeSubTab === 'roles' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {USER_ROLES_DATA.map((role, i) => (
            <div key={i} className="bg-[#0c1424] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                  <h3 className="text-sm font-bold text-white">{role.role}</h3>
                  <span className="text-[10px] font-mono text-purple-300 bg-purple-950 px-2 py-0.5 rounded border border-purple-800">
                    {role.badge}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mb-4 leading-relaxed">
                  {role.description}
                </p>

                <div className="space-y-1.5 text-xs">
                  <div className="text-[10px] uppercase font-bold text-slate-500 font-mono">Assigned Privileges:</div>
                  {role.permissions.map((perm, pIdx) => (
                    <div key={pIdx} className="flex items-start gap-2 text-[11px] text-slate-300">
                      <span className="text-sky-400">▪</span>
                      <span className="leading-snug">{perm}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 mt-4 text-[10px] font-mono text-slate-500">
                RBAC Level: Tier {i + 1} Access
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Sub-tab 3: Supabase Schema */}
      {activeSubTab === 'schema' && (
        <div className="bg-[#0c1424] border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Database className="w-4 h-4 text-emerald-400" />
                <span>Supabase PostgreSQL Schema & Row Level Security (RLS)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Optimized relational tables with PostGIS extensions for spatial catchment tracking, high-frequency telemetry indices, and foreign key cascades.
              </p>
            </div>

            <button
              onClick={handleCopySchema}
              className="px-3 py-1.5 rounded text-xs font-mono bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-200 flex items-center gap-1.5 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied DDL' : 'Copy SQL'}</span>
            </button>
          </div>

          <div className="rounded-lg bg-[#080d19] border border-slate-800 p-4 overflow-x-auto max-h-[500px]">
            <pre className="text-xs font-mono text-slate-300 leading-relaxed">
              <code>{SUPABASE_SCHEMA_SQL}</code>
            </pre>
          </div>
        </div>
      )}

      {/* Sub-tab 4: API Endpoints */}
      {activeSubTab === 'api' && (
        <div className="space-y-4">
          {API_ENDPOINTS_SPEC.map((endpoint, i) => (
            <div key={i} className="bg-[#0c1424] border border-slate-800 rounded-xl p-5 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      endpoint.method === 'GET'
                        ? 'bg-sky-950 text-sky-400 border border-sky-800'
                        : endpoint.method === 'POST'
                        ? 'bg-purple-950 text-purple-400 border border-purple-800'
                        : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                    }`}
                  >
                    {endpoint.method}
                  </span>
                  <span className="font-mono text-xs font-bold text-white">{endpoint.path}</span>
                </div>
                <span className="text-[10px] font-mono text-slate-500 uppercase">{endpoint.category}</span>
              </div>

              <p className="text-xs text-slate-300">{endpoint.description}</p>

              <div className="rounded bg-[#080d19] border border-slate-800/80 p-3 overflow-x-auto">
                <div className="text-[10px] text-slate-500 font-mono mb-1">SAMPLE JSON RESPONSE:</div>
                <pre className="text-[11px] font-mono text-sky-300 leading-relaxed">
                  <code>{endpoint.responseSample}</code>
                </pre>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Sub-tab 5: Tech Stack & Hardware BOM */}
      {activeSubTab === 'stack' && (
        <div className="space-y-6">
          {/* Tech Stack Matrix */}
          <div className="bg-[#0c1424] border border-slate-800 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Cpu className="w-4 h-4 text-purple-400" />
              <span>Recommended Production Tech Stack</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-2">
                <div className="font-bold text-sky-400 uppercase font-mono text-[11px]">Frontend & Visualizer</div>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  React 19 + TypeScript + Tailwind CSS with hardware-accelerated SVG charts, WebGL vector mapping, and sub-second reactive state.
                </p>
              </div>
              <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-2">
                <div className="font-bold text-emerald-400 uppercase font-mono text-[11px]">Backend & Database (Supabase)</div>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  Supabase Managed PostgreSQL with PostGIS spatial extensions, Realtime WebSocket subscriptions, Row-Level Security, and automated cold storage partitioning.
                </p>
              </div>
              <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-2">
                <div className="font-bold text-purple-400 uppercase font-mono text-[11px]">Edge ML & SCADA Gateway</div>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  Python ONNX Runtime executing quantized XGBoost and Random Forest models on local industrial edge IPCs (Advantech UNO) with Modbus RTU / OPC-UA polling.
                </p>
              </div>
            </div>
          </div>

          {/* IoT Sensor Bill of Materials (BOM) */}
          <div className="bg-[#0c1424] border border-slate-800 rounded-xl p-5">
            <h3 className="text-sm font-semibold text-white mb-3">
              Powerhouse & Civil Instrumentation Bill of Materials (BOM)
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                    <th className="py-2.5 px-3">Instrumentation Item</th>
                    <th className="py-2.5 px-3">Recommended Model</th>
                    <th className="py-2.5 px-3">Specification / Range</th>
                    <th className="py-2.5 px-3">Installation Location</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {IOT_HARDWARE_BOM.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-850/50">
                      <td className="py-2.5 px-3 font-semibold text-white">{item.item}</td>
                      <td className="py-2.5 px-3 text-sky-400">{item.model}</td>
                      <td className="py-2.5 px-3 text-slate-400">{item.range || item.accuracy || item.frequency || item.os}</td>
                      <td className="py-2.5 px-3 text-slate-300 font-sans text-[11px]">{item.location}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
