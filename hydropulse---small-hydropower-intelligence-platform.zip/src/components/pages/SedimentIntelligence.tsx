import React, { useState } from 'react';
import { Plant } from '../../types/hydro';
import { SEDIMENT_FORECAST_72H } from '../../data/mockHydroData';
import { MetricCard } from '../common/MetricCard';
import { calculateAbrasiveErosionRate } from '../../utils/physicsEngine';
import {
  Waves,
  CloudRain,
  AlertTriangle,
  TrendingDown,
  Layers,
  ArrowDownToLine,
  CheckCircle,
  RefreshCw,
  Info,
} from 'lucide-react';

interface SedimentIntelligenceProps {
  currentPlant: Plant;
}

export const SedimentIntelligence: React.FC<SedimentIntelligenceProps> = ({ currentPlant }) => {
  const [selectedHour, setSelectedHour] = useState<number>(12); // Default to +12h forecast point
  const [isPurging, setIsPurging] = useState<boolean>(false);
  const [purgeSuccess, setPurgeSuccess] = useState<boolean>(false);

  const forecastData = SEDIMENT_FORECAST_72H;
  const currentForecastPoint = forecastData.find((d) => d.hourOffset === selectedHour) || forecastData[3];

  const erosionRate = calculateAbrasiveErosionRate(
    currentPlant.currentTurbidityNTU,
    currentPlant.currentHeadM,
    currentPlant.quartzContentPercent / 100,
    false
  );

  const handleTriggerPurge = () => {
    setIsPurging(true);
    setTimeout(() => {
      setIsPurging(false);
      setPurgeSuccess(true);
      setTimeout(() => setPurgeSuccess(false), 5000);
    }, 2000);
  };

  // SVG Chart Dimensions for 72h Forecast
  const chartWidth = 740;
  const chartHeight = 240;
  const padding = { top: 20, right: 40, bottom: 35, left: 45 };
  const graphWidth = chartWidth - padding.left - padding.right;
  const graphHeight = chartHeight - padding.top - padding.bottom;

  const maxNTU = 2200;
  const maxRain = 40;

  const getX = (idx: number) => padding.left + (idx / (forecastData.length - 1)) * graphWidth;
  const getY_NTU = (val: number) => padding.top + (1 - val / maxNTU) * graphHeight;
  const getY_Rain = (val: number) => padding.top + (1 - val / maxRain) * graphHeight;

  const ntuPoints = forecastData.map((d, i) => `${getX(i)},${getY_NTU(d.predictedSedimentNTU)}`).join(' ');

  return (
    <div className="space-y-6">
      {/* Module Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="text-xs font-mono text-amber-400 flex items-center gap-1.5 mb-1">
            <Waves className="w-3.5 h-3.5" />
            <span>CORE INTELLIGENCE MODULE 01 · IEC 62364 STANDARD</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Sediment & Erosion Forecasting + Energy-Loss Intelligence
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Continuous multi-source sediment monitoring integrating upstream Himalayan catchment rainfall-runoff models, quartz petrography, hydro-abrasive runner degradation, and automated desilter purging.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleTriggerPurge}
            disabled={isPurging}
            className={`px-3 py-2 rounded text-xs font-semibold flex items-center gap-1.5 transition-colors border ${
              isPurging
                ? 'bg-amber-950/60 border-amber-800 text-amber-300'
                : purgeSuccess
                ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                : 'bg-slate-900 border-slate-700 hover:border-amber-600 text-slate-200'
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isPurging ? 'animate-spin' : ''}`} />
            <span>
              {isPurging
                ? 'Flushing Hoppers...'
                : purgeSuccess
                ? 'Desilter Flushed (180s)'
                : 'Trigger Desilter Purge'}
            </span>
          </button>
        </div>
      </div>

      {/* Primary Key Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <MetricCard
          label="Current Silt Turbidity"
          value={currentPlant.currentTurbidityNTU}
          unit="NTU"
          subLabel="Concentration"
          subValue={`${Math.round(currentPlant.currentTurbidityNTU * 1.35)} ppm`}
          status={currentPlant.currentTurbidityNTU > 500 ? 'warning' : 'nominal'}
          icon={<Waves className="w-3.5 h-3.5 text-amber-400" />}
          trend={{ direction: 'up', value: 'Rising Inflow' }}
        />
        <MetricCard
          label="Catchment Quartz Content"
          value={currentPlant.quartzContentPercent}
          unit="%"
          subLabel="Mohs Hardness"
          subValue="> 7.0 Hardness"
          status="warning"
          icon={<Layers className="w-3.5 h-3.5 text-amber-400" />}
        />
        <MetricCard
          label="Runner Abrasive Wear"
          value={erosionRate}
          unit="mm/1k h"
          subLabel="IEC 62364 Rate"
          subValue="13Cr4Ni Runner"
          status={erosionRate > 0.2 ? 'warning' : 'nominal'}
          icon={<TrendingDown className="w-3.5 h-3.5 text-rose-400" />}
          trend={{ direction: 'up', value: '+18% Monsoon' }}
        />
        <MetricCard
          label="24h Projected Silt Loss"
          value="4.85"
          unit="MWh"
          subLabel="Tariff Loss"
          subValue="₹20,612 / Day"
          status="advisory"
          icon={<AlertTriangle className="w-3.5 h-3.5 text-amber-400" />}
        />
        <MetricCard
          label="Desilter Settling Ratio"
          value="88.5"
          unit="%"
          subLabel="Target Trapping"
          subValue=">0.2 mm Silt"
          status="nominal"
          icon={<ArrowDownToLine className="w-3.5 h-3.5 text-blue-400" />}
        />
        <MetricCard
          label="Peak 72h Inflow NTU"
          value="1,850"
          unit="NTU"
          subLabel="Peak Surge At"
          subValue="+18 Hours"
          status="critical"
          icon={<CloudRain className="w-3.5 h-3.5 text-rose-400" />}
        />
      </div>

      {/* Main Visualizer: 72h Forecast Chart */}
      <div className="bg-[#0c1424] border border-slate-800 rounded-xl p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <span>72-Hour Catchment Rainfall & Sediment Concentration Forecast</span>
              <span className="text-[10px] font-mono text-purple-400">XGBoost Regressor v2.4</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Dual-variable hydrograph correlating upstream catchment rainfall (mm) with predicted river sediment turbidity (NTU)
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-amber-400 inline-block" />
              <span className="text-slate-300">Predicted Turbidity (NTU)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-sky-500/50 inline-block" />
              <span className="text-slate-300">Catchment Rainfall (mm)</span>
            </div>
          </div>
        </div>

        {/* SVG Forecast Graph */}
        <div className="py-4">
          <svg
            viewBox={`0 0 ${chartWidth} ${chartHeight}`}
            className="w-full h-auto overflow-visible select-none"
          >
            {/* Horizontal Grid lines */}
            {[500, 1000, 1500, 2000].map((val) => (
              <g key={val}>
                <line
                  x1={padding.left}
                  y1={getY_NTU(val)}
                  x2={padding.left + graphWidth}
                  y2={getY_NTU(val)}
                  stroke="#1e293b"
                  strokeDasharray="3 3"
                />
                <text
                  x={padding.left - 8}
                  y={getY_NTU(val) + 3}
                  textAnchor="end"
                  fill="#64748b"
                  fontSize="10"
                  fontFamily="monospace"
                >
                  {val}
                </text>
              </g>
            ))}

            {/* Critical Silt Threshold Guide line at 1500 NTU */}
            <line
              x1={padding.left}
              y1={getY_NTU(1500)}
              x2={padding.left + graphWidth}
              y2={getY_NTU(1500)}
              stroke="#ef4444"
              strokeDasharray="4 2"
              strokeWidth="1.2"
            />
            <text
              x={padding.left + graphWidth - 10}
              y={getY_NTU(1500) - 6}
              textAnchor="end"
              fill="#ef4444"
              fontSize="10"
              fontFamily="monospace"
              fontWeight="bold"
            >
              RUNNER DERATING THRESHOLD (1500 NTU)
            </text>

            {/* Rainfall Bar Columns */}
            {forecastData.map((d, i) => {
              const barWidth = 14;
              const barHeight = (d.rainfallMm / maxRain) * graphHeight;
              const xPos = getX(i) - barWidth / 2;
              const yPos = padding.top + graphHeight - barHeight;
              return (
                <rect
                  key={`rain-${i}`}
                  x={xPos}
                  y={yPos}
                  width={barWidth}
                  height={barHeight}
                  fill="#0284c7"
                  opacity="0.45"
                  rx="2"
                />
              );
            })}

            {/* Turbidity Forecast Line */}
            <polyline
              points={ntuPoints}
              fill="none"
              stroke="#f59e0b"
              strokeWidth="2.5"
            />

            {/* Interactive Data Points */}
            {forecastData.map((d, i) => (
              <g
                key={`point-${i}`}
                onClick={() => setSelectedHour(d.hourOffset)}
                className="cursor-pointer"
              >
                <circle
                  cx={getX(i)}
                  cy={getY_NTU(d.predictedSedimentNTU)}
                  r={selectedHour === d.hourOffset ? 6 : 3.5}
                  fill={selectedHour === d.hourOffset ? '#ffffff' : '#f59e0b'}
                  stroke="#0a101f"
                  strokeWidth="2"
                />
                <text
                  x={getX(i)}
                  y={chartHeight - 10}
                  textAnchor="middle"
                  fill={selectedHour === d.hourOffset ? '#f8fafc' : '#64748b'}
                  fontSize="10"
                  fontFamily="monospace"
                  fontWeight={selectedHour === d.hourOffset ? 'bold' : 'normal'}
                >
                  {d.timeLabel}
                </text>
              </g>
            ))}
          </svg>
        </div>

        {/* Selected Hour Insight Card */}
        <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-white bg-slate-800 px-2 py-0.5 rounded">
                HORIZON {currentForecastPoint.timeLabel}
              </span>
              <span className="text-xs text-slate-400">·</span>
              <span
                className={`text-xs font-semibold ${
                  currentForecastPoint.erosionRiskLevel === 'critical'
                    ? 'text-rose-400'
                    : currentForecastPoint.erosionRiskLevel === 'elevated'
                    ? 'text-amber-400'
                    : 'text-emerald-400'
                }`}
              >
                {currentForecastPoint.erosionRiskLevel.toUpperCase()} EROSION RISK
              </span>
            </div>
            <p className="text-xs text-slate-300">
              <strong>SOP Recommendation:</strong> {currentForecastPoint.recommendedAction}
            </p>
          </div>

          <div className="flex items-center gap-5 text-xs font-mono shrink-0">
            <div>
              <div className="text-[10px] text-slate-500 uppercase">Rainfall</div>
              <div className="text-sky-400 font-bold">{currentForecastPoint.rainfallMm} mm</div>
            </div>
            <div>
              <div className="text-[10px] text-slate-500 uppercase">Silt Inflow</div>
              <div className="text-amber-400 font-bold">{currentForecastPoint.predictedSedimentNTU} NTU</div>
            </div>
            <div>
              <div className="text-[10px] text-slate-500 uppercase">Est. Energy Loss</div>
              <div className="text-rose-400 font-bold">-{currentForecastPoint.estimatedLossMWh} MWh</div>
            </div>
          </div>
        </div>
      </div>

      {/* Grid: 72h Forecast Log Table & Petrographic Mineral Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Forecast Table (8 cols) */}
        <div className="lg:col-span-8 bg-[#0c1424] border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <h3 className="text-sm font-semibold text-white">72-Hour Discrete Inflow & Loss Log</h3>
            <span className="text-xs text-slate-500 font-mono">10 Timesteps</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-mono text-[11px]">
                  <th className="py-2 px-2">Horizon</th>
                  <th className="py-2 px-2">Rain (mm)</th>
                  <th className="py-2 px-2">Flow (m³/s)</th>
                  <th className="py-2 px-2">Silt (NTU)</th>
                  <th className="py-2 px-2">Loss (MWh)</th>
                  <th className="py-2 px-2">Risk Level</th>
                  <th className="py-2 px-2">Operational Response</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {forecastData.map((row) => (
                  <tr
                    key={row.hourOffset}
                    onClick={() => setSelectedHour(row.hourOffset)}
                    className={`hover:bg-slate-850/60 transition-colors cursor-pointer ${
                      selectedHour === row.hourOffset ? 'bg-slate-850' : ''
                    }`}
                  >
                    <td className="py-2 px-2 font-bold text-white">{row.timeLabel}</td>
                    <td className="py-2 px-2 text-sky-400">{row.rainfallMm}</td>
                    <td className="py-2 px-2 text-slate-300">{row.riverFlowM3s}</td>
                    <td className="py-2 px-2 text-amber-400 font-bold">{row.predictedSedimentNTU}</td>
                    <td className="py-2 px-2 text-rose-400">-{row.estimatedLossMWh}</td>
                    <td className="py-2 px-2">
                      <span
                        className={`text-[10px] font-semibold ${
                          row.erosionRiskLevel === 'critical'
                            ? 'text-rose-400'
                            : row.erosionRiskLevel === 'elevated'
                            ? 'text-amber-400'
                            : 'text-emerald-400'
                        }`}
                      >
                        {row.erosionRiskLevel.toUpperCase()}
                      </span>
                    </td>
                    <td className="py-2 px-2 text-[11px] font-sans text-slate-300 truncate max-w-xs">
                      {row.recommendedAction}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Petrographic Mineral Breakdown (4 cols) */}
        <div className="lg:col-span-4 bg-[#0c1424] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <h3 className="text-sm font-semibold text-white">Quartz Petrography & Hardness</h3>
              <Info className="w-3.5 h-3.5 text-slate-500" />
            </div>

            <p className="text-xs text-slate-400 mb-4 leading-relaxed">
              Himalayan river silt particles exceeding 7 on the Mohs hardness scale trigger micro-cutting and fatigue wear on turbine blades under high jet impingement velocity.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Quartz (SiO₂) - Hardness 7.0</span>
                  <span className="font-mono text-amber-400 font-semibold">{currentPlant.quartzContentPercent}%</span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-amber-400 h-1.5 rounded-full"
                    style={{ width: `${currentPlant.quartzContentPercent}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Feldspar - Hardness 6.0</span>
                  <span className="font-mono text-slate-300">12.4%</span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                  <div className="bg-sky-400 h-1.5 rounded-full" style={{ width: '12.4%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Mica / Biotite - Hardness 2.8</span>
                  <span className="font-mono text-slate-300">6.2%</span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                  <div className="bg-slate-400 h-1.5 rounded-full" style={{ width: '6.2%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Calcite & Organics - Hardness 3.0</span>
                  <span className="font-mono text-slate-300">3.0%</span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                  <div className="bg-slate-600 h-1.5 rounded-full" style={{ width: '3.0%' }} />
                </div>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 mt-4 text-[11px] text-slate-400 space-y-1">
            <div className="flex justify-between font-mono">
              <span className="text-slate-500">Particle Size d50:</span>
              <span className="text-white">0.18 mm</span>
            </div>
            <div className="flex justify-between font-mono">
              <span className="text-slate-500">Abrasiveness Index K:</span>
              <span className="text-amber-400">3.42 × 10⁻³ mm/hr</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
