import React from 'react';

interface MetricCardProps {
  label: string;
  value: string | number;
  unit?: string;
  subValue?: string;
  subLabel?: string;
  status?: 'nominal' | 'advisory' | 'warning' | 'critical' | 'ai';
  icon?: React.ReactNode;
  trend?: {
    direction: 'up' | 'down' | 'neutral';
    value: string;
  };
}

export const MetricCard: React.FC<MetricCardProps> = ({
  label,
  value,
  unit,
  subValue,
  subLabel,
  status = 'nominal',
  icon,
  trend,
}) => {
  const getStatusBorder = () => {
    switch (status) {
      case 'critical':
        return 'border-rose-900/60 hover:border-rose-700/80';
      case 'warning':
      case 'advisory':
        return 'border-amber-900/60 hover:border-amber-700/80';
      case 'ai':
        return 'border-purple-900/60 hover:border-purple-700/80';
      case 'nominal':
      default:
        return 'border-slate-800 hover:border-slate-700';
    }
  };

  const getStatusIndicator = () => {
    switch (status) {
      case 'critical':
        return 'bg-rose-500';
      case 'warning':
      case 'advisory':
        return 'bg-amber-400';
      case 'ai':
        return 'bg-purple-400';
      case 'nominal':
      default:
        return 'bg-emerald-400';
    }
  };

  return (
    <div
      className={`p-4 rounded-lg bg-[#0e1626] border transition-colors ${getStatusBorder()}`}
    >
      <div className="flex items-center justify-between gap-2 mb-2">
        <div className="text-xs text-slate-400 font-medium tracking-wide truncate">
          {label}
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          <span className={`w-1.5 h-1.5 rounded-full ${getStatusIndicator()}`} />
          {icon && <span className="text-slate-400">{icon}</span>}
        </div>
      </div>

      <div className="flex items-baseline gap-1.5">
        <span className="text-2xl font-bold font-mono text-white tracking-tight tabular-nums">
          {value}
        </span>
        {unit && (
          <span className="text-xs font-mono text-slate-400 font-medium">
            {unit}
          </span>
        )}
      </div>

      {(subValue || trend) && (
        <div className="mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
          {subValue ? (
            <div className="truncate">
              {subLabel && <span className="text-slate-500 mr-1">{subLabel}:</span>}
              <span className="font-mono text-slate-300">{subValue}</span>
            </div>
          ) : <div />}

          {trend && (
            <span
              className={`font-mono font-medium ${
                trend.direction === 'up'
                  ? 'text-emerald-400'
                  : trend.direction === 'down'
                  ? 'text-rose-400'
                  : 'text-slate-400'
              }`}
            >
              {trend.direction === 'up' ? '↑ ' : trend.direction === 'down' ? '↓ ' : ''}
              {trend.value}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
