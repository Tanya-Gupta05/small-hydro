export type TurbineType = 'Francis' | 'Pelton' | 'Kaplan';

export interface Plant {
  id: string;
  name: string;
  state: string;
  river: string;
  basin: string;
  capacityMW: number;
  netHeadM: number;
  designDischargeM3s: number;
  turbineType: TurbineType;
  unitsCount: number;
  commissionYear: number;
  status: 'nominal' | 'advisory' | 'critical';
  coordinates: {
    lat: number;
    lng: number;
  };
  elevationM: number;
  catchmentAreaKm2: number;
  quartzContentPercent: number; // Mineral hardness (>6 Mohs causes abrasive erosion)
  currentFlowM3s: number;
  currentHeadM: number;
  currentPowerMW: number;
  expectedPowerMW: number;
  currentTurbidityNTU: number;
  activeAlertsCount: number;
}

export interface TelemetryPoint {
  timestamp: string;
  flowM3s: number;
  headM: number;
  tailwaterM: number;
  rpm: number;
  vibrationMmS: number; // ISO 10816-5 limit is typically 4.5 mm/s warning, 7.1 mm/s trip
  bearingTempC: number;
  generatorTempC: number;
  powerMW: number;
  expectedMW: number;
  efficiencyPercent: number;
  sedimentNTU: number;
  guideVanePercent: number;
}

export interface SedimentForecastHour {
  hourOffset: number; // +1h to +72h
  timeLabel: string;
  rainfallMm: number;
  cumulativeRainfallMm: number;
  riverFlowM3s: number;
  predictedSedimentNTU: number;
  predictedPPM: number;
  quartzFraction: number;
  erosionRiskLevel: 'nominal' | 'moderate' | 'elevated' | 'critical';
  estimatedLossMWh: number;
  recommendedAction: string;
}

export interface TurbineUnitDetail {
  unitId: string;
  name: string;
  ratedMW: number;
  currentMW: number;
  rpm: number;
  efficiency: number;
  healthScore: number; // 0 - 100
  status: 'running' | 'derated' | 'maintenance' | 'flushing';
  erosionStage: 'Stage 1 (Polishing)' | 'Stage 2 (Pitting)' | 'Stage 3 (Wavy Grooves)' | 'Stage 4 (Material Loss)';
  runnerMaterial: string;
  hoursSinceLastOverhaul: number;
  vibrationSpectrum: {
    freqHz: number;
    amplitudeMmS: number;
    limitMmS: number;
  }[];
  temperatureSensors: {
    location: string;
    valueC: number;
    thresholdC: number;
    status: 'normal' | 'warm' | 'critical';
  }[];
  acousticEmissionDb: number;
}

export interface OperatingDispatchUnit {
  unitId: string;
  status: 'online' | 'standby' | 'scheduled_flushing';
  currentGVO: number; // Guide Vane Opening %
  optimalGVO: number;
  currentFlow: number;
  optimalFlow: number;
  currentMW: number;
  optimalMW: number;
  efficiencyGain: number; // %
}

export interface ResilienceScenario {
  id: string;
  name: string;
  type: 'flood' | 'sediment_surge' | 'drought' | 'debris' | 'tailwater_rise';
  triggerCriteria: string;
  probabilityPercent: number;
  predictedGenerationImpactMWh: number;
  runnerDamageRisk: 'Low' | 'Moderate' | 'Severe' | 'Catastrophic';
  recommendedSOP: string[];
  autoDispatchAction: string;
  status: 'idle' | 'monitoring' | 'active_warning';
}

export interface WhatIfInputs {
  rainfallMm: number;
  inflowM3s: number;
  grossHeadM: number;
  tailwaterRiseM: number;
  sedimentNTU: number;
  runnerErosionPct: number;
  guideVanePercent: number;
  quartzRatio: number;
}

export interface WhatIfOutputs {
  netHeadM: number;
  effectiveFlowM3s: number;
  mechanicalEfficiency: number;
  electricalEfficiency: number;
  overallEfficiency: number;
  electricalPowerMW: number;
  expectedPowerMW: number;
  powerDeltaMW: number;
  cavitationSigma: number;
  cavitationRisk: 'Safe' | 'Marginal' | 'Incipient Cavitation' | 'Severe Cavitation';
  erosionRateMmPer1000h: number;
  estimatedBladeLifeMonths: number;
  revenuePerDayINR: number;
  dailyRevenueLossINR: number;
}

export interface PlantRevampOption {
  id: string;
  title: string;
  category: 'Runner Upgrade' | 'Digital Automation' | 'Desilting Basin' | 'Generator Rewind';
  description: string;
  estimatedCapexLakhINR: number;
  annualGenerationGainMWh: number;
  annualRevenueGainLakhINR: number;
  paybackPeriodYears: number;
  co2OffsetTonsPerYear: number;
  status: 'Recommended' | 'Under Feasibility' | 'Planned Phase 2';
}

export interface AlertItem {
  id: string;
  plantId: string;
  unit?: string;
  timestamp: string;
  level: 'info' | 'warning' | 'critical';
  title: string;
  source: string;
  details: string;
  suggestedMitigation: string;
  acknowledged: boolean;
}
